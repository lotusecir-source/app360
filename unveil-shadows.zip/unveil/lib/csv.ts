import { Data, DAYS, H, dayDate, MONTHS, CATS } from './data';
import { buildCases } from './cases';

const iso = (d: number) => dayDate(d).toISOString().slice(0, 10);
const esc = (v: any) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
const toCsv = (head: string[], rows: any[][]) => [head.join(','), ...rows.map(r => r.map(esc).join(','))].join('\n');

export function csvFiles(D: Data): Record<string, string> {
  const { cases } = buildCases(D);
  const f: Record<string, string> = {};
  f['consumers.csv'] = toCsv(['service_id', 'section', 'dt_gis', 'feeder', 'category', 'meter_type', 'meter_id', 'reader', 'sanctioned_kw', 'lat', 'lng', 'ration_card_hash', 'house_id'],
    D.consumers.map(c => [c.id, c.sec, c.dt, c.feeder, CATS[c.cat].label, c.meter, c.meterId, c.meter === 'Manual' ? c.reader : '', c.kw, c.lat.toFixed(5), c.lng.toFixed(5), c.rc || '', c.house]));
  f['bills.csv'] = toCsv(['service_id', 'month', 'units_actual_truth', 'units_reported', 'amount_rs', 'zero_bill', 'gj_eligible'],
    D.bills.map(b => [b.cid, MONTHS[b.m].key + '-2026', b.units, b.reported, b.amount, b.zero, b.gjEligible]));
  f['payments.csv'] = toCsv(['payment_id', 'service_id', 'bill_month', 'amount_rs', 'paid_on', 'channel', 'counter', 'settled_on'],
    D.payments.map(p => [p.id, p.cid, MONTHS[p.m].key + '-2026', p.amt, iso(p.day), p.channel, p.counter || '', p.settledDay === null ? '' : iso(Math.min(p.settledDay, DAYS - 1))]));
  const dtRows: any[][] = [];
  for (const dt of D.dts) for (let d = 0; d < DAYS; d++) for (let h = 0; h < H; h++) dtRows.push([dt.id, iso(d), h, dt.inp[d * H + h].toFixed(2), dt.met[d * H + h].toFixed(2), dt.tlEst.toFixed(4)]);
  f['dt_hourly.csv'] = toCsv(['dt_id', 'date', 'hour', 'kwh_in', 'kwh_downstream_metered', 'tech_loss_estimate'], dtRows);
  f['meter_events.csv'] = toCsv(['event_id', 'meter_id', 'service_id', 'date', 'hour', 'event'], D.events.map(e => [e.id, e.meterId, e.cid, iso(e.day), e.hour, e.type]));
  f['work_orders.csv'] = toCsv(['wo_id', 'service_id', 'date', 'type', 'text'], D.workOrders.map(w => [w.id, w.cid, iso(w.day), w.type, w.text]));
  f['tickets.csv'] = toCsv(['ticket_id', 'date', 'section', 'service_id', 'channel', 'type', 'text', 'status', 'root_cause', 'fix'],
    D.tickets.map(t => [t.id, iso(t.day), t.sec, t.cid || '', t.channel, t.type, t.text, t.status, t.rootCause || '', t.fix || '']));
  f['gj_claims.csv'] = toCsv(['month', 'service_id', 'claim_rs'], D.claims.map(c => [MONTHS[c.m].key + '-2026', c.cid, c.amount]));
  f['ground_truth.csv'] = toCsv(['case_id', 'scenario', 'entity', 'category', 'detected_on', 'agent_proposed', 'ground_truth', 'note'],
    cases.map(c => [c.id, c.title, c.entity, c.category, iso(c.day), c.proposed, c.truth, c.truthNote]));
  return f;
}

export function downloadAll(D: Data) {
  const files = csvFiles(D);
  Object.entries(files).forEach(([name, body], i) => setTimeout(() => {
    const url = URL.createObjectURL(new Blob([body], { type: 'text/csv' }));
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }, i * 350));
}
