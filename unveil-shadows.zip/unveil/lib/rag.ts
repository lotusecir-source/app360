// Tiny in-browser retrieval: TF-IDF + cosine over past tickets (with recorded root causes).
import type { Ticket } from './data';

const STOP = new Set('the a an is are was in on of to for and or but not my our we i it this that at by with from has have been please since very much still'.split(' '));
const tok = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter(w => w.length > 2 && !STOP.has(w)).map(w => w.replace(/(ing|ed|s)$/, ''));

export function buildIndex(docs: Ticket[]) {
  const df = new Map<string, number>();
  const toks = docs.map(d => { const t = tok(d.type + ' ' + d.text); new Set(t).forEach(w => df.set(w, (df.get(w) || 0) + 1)); return t; });
  const N = docs.length;
  const idf = (w: string) => Math.log((N + 1) / ((df.get(w) || 0) + 1)) + 1;
  const vec = (t: string[]) => { const m = new Map<string, number>(); t.forEach(w => m.set(w, (m.get(w) || 0) + 1)); let n = 0; m.forEach((v, k) => { const x = v * idf(k); m.set(k, x); n += x * x; }); n = Math.sqrt(n) || 1; m.forEach((v, k) => m.set(k, v / n)); return m; };
  const vecs = toks.map(vec);
  return {
    search(q: string, k = 3) {
      const qv = vec(tok(q));
      const scored = vecs.map((v, i) => { let s = 0; qv.forEach((x, w) => { const y = v.get(w); if (y) s += x * y; }); return { doc: docs[i], score: s }; });
      // collapse identical texts, keep variety of root causes
      const seen = new Set<string>(); const out: { doc: Ticket; score: number }[] = [];
      for (const r of scored.sort((a, b) => b.score - a.score)) { const key = r.doc.rootCause + '|' + r.doc.text; if (seen.has(key)) continue; seen.add(key); out.push(r); if (out.length >= k) break; }
      return out;
    },
  };
}
