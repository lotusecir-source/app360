import { Data, dayOf, fmtDay, fmtDayHour, residual, residualRange, H, MONTHS, CATS, SECTIONS, GJ_CAP, SHAPES, DAYS, rng } from './data';

export type Outcome = 'Suspected misconduct referral' | 'Fault' | 'Data defect' | 'Billing error' | 'Payment issue' | 'Legitimate change' | 'Inconclusive';
export interface Ev { id: string; label: string; value: string }
export interface Step { tool: string; ask: string; result: string; ev: Ev[]; hyp: Record<string, number>; note?: string }
export interface Output { type: 'Inspection order' | 'Bill correction' | 'Payment reconciliation' | 'Work order' | 'Consumer alert' | 'Subsidy claim correction' | 'Data fix' | 'Monitoring'; text: string }
export interface Case {
  id: string; key: string; title: string; sec: string; entity: string; entityType: 'DT' | 'Consumer' | 'Counter' | 'Reader' | 'Gateway' | 'Area' | 'Household';
  day: number; hour: number; severity: 'High' | 'Medium' | 'Low'; category: string; agent: string;
  summary: string; hyp0: Record<string, number>; steps: Step[]; proposed: Outcome; truth: Outcome; truthNote: string;
  action: string; exposure: { kwh?: number; rs: number; basis: string }; outputs: Output[]; planted: boolean; lat: number; lng: number;
}
export interface Alert { id: string; day: number; hour: number; sec: string; sev: 'High' | 'Medium' | 'Low'; title: string; caseId?: string; source: string }

const RATE = 7.5; // illustrative average realisation Rs/kWh
const pct = (x: number, d = 1) => `${(x * 100).toFixed(d)}%`;
const kwh = (x: number) => `${Math.round(x).toLocaleString('en-IN')} kWh`;
export const rs = (x: number) => '₹' + Math.round(x).toLocaleString('en-IN');
const avg = (a: Float32Array, d0: number, d1: number) => { let s = 0; for (let d = d0; d <= d1; d++) s += a[d]; return s / (d1 - d0 + 1); };

export function buildCases(D: Data) {
  const { P, byId, dtById } = D;
  const cases: Case[] = [];
  const secName = (c: string) => SECTIONS.find(s => s.code === c)!.name;

  // ---------------------------------------------------------------- S1 LV tap
  {
    const dt = dtById.get(P.S1.dt)!; const from = P.S1.from; const det = from + 3;
    const nightRes = (d0: number, d1: number) => { let i = 0, r = 0; for (let d = d0; d <= d1; d++) for (const h of [22, 23, 0, 1, 2, 3, 4]) { const x = residual(dt, h < 12 ? d + 1 : d, h); i += x.inp; r += x.res; } return { pct: r / i, kwhPerNight: r / (d1 - d0 + 1) }; };
    const dayRes = (d0: number, d1: number) => { let i = 0, r = 0; for (let d = d0; d <= d1; d++) for (let h = 8; h <= 18; h++) { const x = residual(dt, d, h); i += x.inp; r += x.res; } return r / i; };
    const before = nightRes(from - 17, from - 1), after = nightRes(from, det - 1);
    const nb = ['KKP-DT-06', 'KKP-DT-08'].map(id => residualRange(dtById.get(id)!, from, det - 1).pct);
    const nights = DAYS - 1 - from; const tot = nightRes(from, DAYS - 2).kwhPerNight * nights;
    const near = byId.get(P.S1.near)!;
    const tk = D.tickets.find(t => t.type === 'Illegal connection report' && !t.past)!;
    cases.push({
      id: 'CASE-101', key: 'S1', title: `Recurring night-time energy gap at ${dt.id}`, sec: 'KKP', entity: dt.id, entityType: 'DT', day: det, hour: 2, severity: 'High',
      category: 'Unauthorized connections / direct abstraction', agent: 'Loss agent', planted: true, lat: dt.lat, lng: dt.lng,
      summary: `Energy entering ${dt.id} between 22:00 and 05:00 is no longer matched by downstream meters. The gap repeats every night since ${fmtDay(from)}.`,
      hyp0: { 'Unauthorized tap / direct supply': 0.25, 'Technical-loss change': 0.2, 'GIS mapping error': 0.2, 'DT meter / CT error': 0.15, 'Data gap': 0.2 },
      steps: [
        { tool: 'check_data_quality', ask: `${dt.id} DT meter, 1–20 Sep`, result: 'All 480 hourly intervals present; no comms loss; CT ratio unchanged since commissioning.', ev: [{ id: `EV-DQ-${dt.id}`, label: 'Interval completeness', value: '480 / 480' }], hyp: { 'Unauthorized tap / direct supply': 0.32, 'Technical-loss change': 0.26, 'GIS mapping error': 0.24, 'DT meter / CT error': 0.16, 'Data gap': 0.02 } },
        { tool: 'energy_balance', ask: `${dt.id}, night (22–05) vs day (08–18), before and after ${fmtDay(from)}`, result: `Night residual rose from ${pct(before.pct)} to ${pct(after.pct)} (≈${kwh(after.kwhPerNight)} per night). Daytime residual unchanged at ${pct(dayRes(from, det - 1))}. A technical-loss change would rise with load at all hours.`, ev: [{ id: `EV-EB-${dt.id}-N`, label: 'Night residual before → after', value: `${pct(before.pct)} → ${pct(after.pct)}` }, { id: `EV-EB-${dt.id}-D`, label: 'Day residual after', value: pct(dayRes(from, det - 1)) }], hyp: { 'Unauthorized tap / direct supply': 0.62, 'Technical-loss change': 0.05, 'GIS mapping error': 0.2, 'DT meter / CT error': 0.11, 'Data gap': 0.02 } },
        { tool: 'gis_connectivity', ask: `Topology changes for ${dt.id} and neighbours`, result: `No consumer re-mapping on this DT since June. Neighbours KKP-DT-06 and KKP-DT-08 show normal residuals (${pct(nb[0])}, ${pct(nb[1])}), so energy is not being billed elsewhere.`, ev: [{ id: 'EV-GIS-KKP-07', label: 'Topology change log', value: 'No changes since Jun' }, { id: 'EV-EB-KKP-06/08', label: 'Neighbour residuals', value: `${pct(nb[0])} / ${pct(nb[1])}` }], hyp: { 'Unauthorized tap / direct supply': 0.78, 'Technical-loss change': 0.05, 'GIS mapping error': 0.04, 'DT meter / CT error': 0.11, 'Data gap': 0.02 } },
        { tool: 'meter_events', ask: `All AMI meters downstream of ${dt.id}`, result: 'No tamper, magnet or disconnect events downstream. Downstream metered night load is flat, so the extra energy is not passing through any consumer meter.', ev: [{ id: 'EV-MTR-KKP-07', label: 'Downstream tamper events', value: '0' }], hyp: { 'Unauthorized tap / direct supply': 0.84, 'Technical-loss change': 0.04, 'GIS mapping error': 0.04, 'DT meter / CT error': 0.06, 'Data gap': 0.02 } },
        { tool: 'estimate_load', ask: 'Size and timing of the unmetered load', result: `≈${(after.kwhPerNight / 7).toFixed(0)} kW average for 7 hours a night: consistent with battery charging (e.g. 15–20 e-rickshaws at ~1 kW). Load = power, not energy; exposure below is a range.`, ev: [{ id: 'EV-EST-KKP-07', label: 'Estimated unmetered load', value: `${(after.kwhPerNight / 7).toFixed(0)} kW × 7 h` }], hyp: { 'Unauthorized tap / direct supply': 0.84, 'Technical-loss change': 0.04, 'GIS mapping error': 0.04, 'DT meter / CT error': 0.06, 'Data gap': 0.02 } },
        { tool: 'rag_search', ask: '"night residual repeating DT e-rickshaw charging"', result: `Closest past tickets: "Unauthorized tap found on inspection — tap removed, case booked". New complaint ${tk.id} (${fmtDay(tk.day)}): "${tk.text}". Registered consumer ${near.id} sits next to the yard.`, ev: [{ id: tk.id, label: 'Public complaint', value: fmtDay(tk.day) }, { id: `EV-CON-${near.id}`, label: 'Nearest registered service', value: `${near.id} (sanctioned ${near.kw} kW)` }], hyp: { 'Unauthorized tap / direct supply': 0.86, 'Technical-loss change': 0.03, 'GIS mapping error': 0.03, 'DT meter / CT error': 0.06, 'Data gap': 0.02 }, note: 'Complaint linked when it arrived on 24 Sep.' },
      ],
      proposed: 'Suspected misconduct referral', truth: 'Suspected misconduct referral', truthNote: 'Planted: 18 kW illegal LV tap feeding e-rickshaw charging, 22:00–05:00 nightly from 18 Sep.',
      action: `Authorized night inspection (22:00–02:00) of the LV network around ${dt.id}; treat as a safety hazard. A network residual cannot identify the responsible premises by itself.`,
      exposure: { kwh: tot, rs: tot * RATE, basis: `${nights} nights × ≈${kwh(nightRes(from, DAYS - 2).kwhPerNight)} at illustrative ₹${RATE}/kWh` },
      outputs: [{ type: 'Inspection order', text: `Night inspection of LV mains near ${dt.id} (charging yard). Safety priority. Bring IR camera and clamp meter.` }, { type: 'Monitoring', text: `Watch ${dt.id} night residual for 14 days after action.` }],
    });
  }

  // ---------------------------------------------------------------- S2 magnet
  {
    const c = byId.get(P.S2.cid)!; const from = P.S2.from; const det = from + 2;
    const evs = D.events.filter(e => e.cid === c.id && e.type.startsWith('Magnet'));
    const b = avg(c.metered, from - 20, from - 1), a = avg(c.metered, from, det);
    const peers = D.consumers.filter(x => x.dt === c.dt && x.cat === 'COM' && x.id !== c.id && x.meter === 'AMI');
    const pb = peers.reduce((s, x) => s + avg(x.metered, from - 20, from - 1), 0) / Math.max(1, peers.length), pa = peers.reduce((s, x) => s + avg(x.metered, from, det), 0) / Math.max(1, peers.length);
    let lost = 0; for (let d = from; d < DAYS; d++) lost += c.actual[d] - c.metered[d];
    cases.push({
      id: 'CASE-102', key: 'S2', title: `Magnet events and under-registration, ${c.id}`, sec: c.sec, entity: c.id, entityType: 'Consumer', day: det, hour: 15, severity: 'High',
      category: 'Meter interference or bypass', agent: 'Meter health agent', planted: true, lat: c.lat, lng: c.lng,
      summary: `Commercial service ${c.id} raised magnet-influence events and its recorded consumption fell sharply while similar shops on the same DT did not change.`,
      hyp0: { 'Meter interference': 0.3, 'Genuine meter fault': 0.25, 'Business slowdown': 0.25, 'Sensor false alarm': 0.2 },
      steps: [
        { tool: 'meter_events', ask: `${c.meterId}, Aug`, result: `${evs.filter(e => e.day <= det).length} magnet-influence events (first ${fmtDayHour(evs[0].day, evs[0].hour)}). No self-diagnostic errors; comms healthy.`, ev: evs.slice(0, 2).map(e => ({ id: e.id, label: e.type, value: fmtDayHour(e.day, e.hour) })), hyp: { 'Meter interference': 0.5, 'Genuine meter fault': 0.12, 'Business slowdown': 0.2, 'Sensor false alarm': 0.18 } },
        { tool: 'register_progression', ask: `${c.id} daily kWh, 20 days before vs after`, result: `Average ${a.toFixed(1)} kWh/day after vs ${b.toFixed(1)} before (${pct(a / b - 1, 0)}). Load shape unchanged: same opening hours, lower magnitude: typical of partial under-registration.`, ev: [{ id: `EV-REG-${c.id}`, label: 'Daily kWh before → after', value: `${b.toFixed(1)} → ${a.toFixed(1)}` }], hyp: { 'Meter interference': 0.62, 'Genuine meter fault': 0.1, 'Business slowdown': 0.16, 'Sensor false alarm': 0.12 } },
        { tool: 'peer_baseline', ask: `Commercial peers on ${c.dt}`, result: `${peers.length} peer shops: ${pb.toFixed(1)} → ${pa.toFixed(1)} kWh/day (no drop). A local slowdown would affect peers too.`, ev: [{ id: `EV-PEER-${c.dt}-COM`, label: 'Peer change', value: pct(pa / pb - 1, 0) }], hyp: { 'Meter interference': 0.74, 'Genuine meter fault': 0.1, 'Business slowdown': 0.06, 'Sensor false alarm': 0.1 } },
        { tool: 'work_orders', ask: `${c.id}, last 90 days`, result: 'No meter exchange, inspection or seal change recorded.', ev: [{ id: `EV-WO-${c.id}`, label: 'Work orders', value: 'None' }], hyp: { 'Meter interference': 0.78, 'Genuine meter fault': 0.1, 'Business slowdown': 0.06, 'Sensor false alarm': 0.06 } },
      ],
      proposed: 'Suspected misconduct referral', truth: 'Suspected misconduct referral', truthNote: 'Planted: magnet applied from 20 Aug, meter registers ~45% of actual.',
      action: 'Authorized inspection with seal check and independent accuracy test (reference meter). Preserve the meter if interference is found.',
      exposure: { kwh: lost, rs: lost * 8.5, basis: 'Actual minus recorded since 20 Aug, at illustrative commercial ₹8.5/kWh' },
      outputs: [{ type: 'Inspection order', text: `Seal + accuracy test for meter ${c.meterId} at ${c.id}.` }, { type: 'Bill correction', text: 'Draft assessed bill to be raised only after test result and officer approval.' }],
    });
  }

  // ---------------------------------------------------------------- S3 threshold gaming
  {
    const ids: string[] = P.S3.cids; const det = dayOf(9, 3);
    const aug = D.bills.filter(b => b.m === 1 && byId.get(b.cid)!.cat === 'GJ');
    const byReader = new Map<string, { n: number; band: number }>();
    for (const b of aug) { const r = byId.get(b.cid)!.reader; const x = byReader.get(r) || { n: 0, band: 0 }; x.n++; if (b.reported >= 190 && b.reported < 200) x.band++; byReader.set(r, x); }
    const others = [...byReader.entries()].filter(([r]) => r !== P.S3.reader);
    const oBand = others.reduce((s, [, x]) => s + x.band, 0) / others.reduce((s, [, x]) => s + x.n, 0);
    const me = byReader.get(P.S3.reader)!;
    const grp = ids.map(id => byId.get(id)!);
    const jul = grp.reduce((s, c) => s + D.billByKey.get(`${c.id}|0`)!.reported, 0) / grp.length;
    const augActual = grp.reduce((s, c) => s + D.billByKey.get(`${c.id}|1`)!.units, 0) / grp.length;
    const r3 = residualRange(dtById.get('MKD-DT-03')!, 31, 61), r3j = residualRange(dtById.get('MKD-DT-03')!, 0, 30);
    let gap = 0; for (const c of grp) for (const m of [1, 2]) { const b = D.billByKey.get(`${c.id}|${m}`)!; gap += b.units - b.reported; }
    cases.push({
      id: 'CASE-103', key: 'S3', title: `Readings bunched just under 200 units, reader ${P.S3.reader}`, sec: 'MKD', entity: P.S3.reader, entityType: 'Reader', day: det, hour: 10, severity: 'Medium',
      category: 'Reading or billing suppression', agent: 'Billing agent', planted: true, lat: dtById.get('MKD-DT-03')!.lat, lng: dtById.get('MKD-DT-03')!.lng,
      summary: `${me.band} of ${me.n} Gruha Jyothi readings posted by ${P.S3.reader} in August fall between 190 and 199 units, keeping every one of them inside the zero-bill limit.`,
      hyp0: { 'Reading suppression': 0.25, 'Genuine low-use homes': 0.35, 'Consumer threshold management': 0.25, 'Reading-cycle variance': 0.15 },
      steps: [
        { tool: 'reading_distribution', ask: 'Aug GJ readings by reader, share in 190–199 band', result: `${P.S3.reader}: ${pct(me.band / me.n, 0)} in band. All other readers: ${pct(oBand, 1)}.`, ev: [{ id: `EV-RD-${P.S3.reader}`, label: 'Share in 190–199', value: `${pct(me.band / me.n, 0)} vs ${pct(oBand, 1)}` }], hyp: { 'Reading suppression': 0.48, 'Genuine low-use homes': 0.12, 'Consumer threshold management': 0.28, 'Reading-cycle variance': 0.12 } },
        { tool: 'history_compare', ask: 'Same services, July reading', result: `July average ${jul.toFixed(0)} units (spread out normally), then August all land at 191–199. Genuine low-use homes would not converge on one narrow band.`, ev: [{ id: 'EV-BILL-JUL-MKD7', label: 'Jul avg units', value: jul.toFixed(0) }], hyp: { 'Reading suppression': 0.58, 'Genuine low-use homes': 0.05, 'Consumer threshold management': 0.27, 'Reading-cycle variance': 0.1 } },
        { tool: 'energy_balance', ask: 'MKD-DT-03 Jul vs Aug', result: `DT residual rose from ${pct(r3j.pct)} to ${pct(r3.pct)}: energy delivered is higher than the readings say. Consumers cannot change what is written in the reader's book.`, ev: [{ id: 'EV-EB-MKD-03', label: 'Residual Jul → Aug', value: `${pct(r3j.pct)} → ${pct(r3.pct)}` }], hyp: { 'Reading suppression': 0.76, 'Genuine low-use homes': 0.04, 'Consumer threshold management': 0.12, 'Reading-cycle variance': 0.08 } },
        { tool: 'reading_photos', ask: `Photo metadata for ${P.S3.reader}, Aug`, result: '9 photo hashes reused across different services; 22 readings logged within 40 seconds of each other.', ev: [{ id: 'EV-PH-MKD7', label: 'Reused photo hashes', value: '9' }], hyp: { 'Reading suppression': 0.84, 'Genuine low-use homes': 0.03, 'Consumer threshold management': 0.07, 'Reading-cycle variance': 0.06 } },
      ],
      proposed: 'Suspected misconduct referral', truth: 'Suspected misconduct referral', truthNote: 'Planted: 34 services read by MR-MKD-7 consumed ≈230–250 units but were recorded at 191–199 in Aug and Sep.',
      action: 'Independent re-reading of the 34 services by a different reader; vigilance referral for the reading process. Do not penalize consumers until re-reading confirms.',
      exposure: { kwh: gap, rs: gap * 5.5, basis: 'Under-recorded units Aug–Sep; subsidy wrongly claimed + lost revenue at illustrative ₹5.5/kWh' },
      outputs: [{ type: 'Work order', text: `Independent re-reading of ${ids.length} services (MKD-DT-03/04) with geo-tagged photos.` }, { type: 'Subsidy claim correction', text: 'Hold Gruha Jyothi claims for these services pending re-reading.' }],
    });
  }

  // ---------------------------------------------------------------- S4 split household
  {
    const grp = (P.S4.cids as string[]).map(id => byId.get(id)!); const det = dayOf(8, 3);
    const units = grp.map(c => D.billByKey.get(`${c.id}|0`)!.reported);
    cases.push({
      id: 'CASE-104', key: 'S4', title: `One ration card linked to ${grp.length} Gruha Jyothi services`, sec: 'GCB', entity: 'H-GCB-4471', entityType: 'Household', day: det, hour: 11, severity: 'Medium',
      category: 'Subsidy / beneficiary misrepresentation', agent: 'Collections agent', planted: true, lat: grp[0].lat, lng: grp[0].lng,
      summary: `Ration card ${P.S4.rc} is linked to ${grp.length} domestic services at the same address, each billed just under the cap (${units.join(', ')} units in July).`,
      hyp0: { 'One household split to stay under cap': 0.3, 'Separate families, shared card error': 0.3, 'Data-entry linkage error': 0.4 },
      steps: [
        { tool: 'scheme_records', ask: `Entitlements for ${P.S4.rc}`, result: `${grp.length} services enrolled against one card: ${grp.map(c => c.id).join(', ')}.`, ev: grp.map(c => ({ id: `EV-GJ-${c.id}`, label: 'Enrolled service', value: c.id })), hyp: { 'One household split to stay under cap': 0.4, 'Separate families, shared card error': 0.25, 'Data-entry linkage error': 0.35 } },
        { tool: 'gis_location', ask: 'Service locations', result: 'All three services geo-tag to the same building, house number H-GCB-4471.', ev: [{ id: 'EV-GIS-H4471', label: 'Same premises', value: '3 services' }], hyp: { 'One household split to stay under cap': 0.55, 'Separate families, shared card error': 0.2, 'Data-entry linkage error': 0.25 } },
        { tool: 'load_correlation', ask: 'Daily kWh correlation between the three services', result: 'Daily usage moves together (correlation 0.9+), combined ≈450 units/month: one household load pattern.', ev: [{ id: 'EV-CORR-H4471', label: 'Combined monthly units', value: `${units.reduce((a, b) => a + b, 0)}` }], hyp: { 'One household split to stay under cap': 0.72, 'Separate families, shared card error': 0.12, 'Data-entry linkage error': 0.16 } },
      ],
      proposed: 'Suspected misconduct referral', truth: 'Suspected misconduct referral', truthNote: 'Planted: one household split across 3 services sharing ration card RC-7F3A21.',
      action: 'Field verification of occupancy; if one household, keep one entitlement and regularise the others. Validate against authorized scheme records, with human review.',
      exposure: { rs: 2 * 3 * 820, basis: 'Two excess entitlements × 3 months at an illustrative ₹820 claim each' },
      outputs: [{ type: 'Work order', text: 'Occupancy verification at H-GCB-4471.' }, { type: 'Subsidy claim correction', text: 'Flag 2 of 3 entitlements for review in next claim file.' }],
    });
  }

  // ---------------------------------------------------------------- S5 domestic used as shop
  {
    const c = byId.get(P.S5.cid)!; const det = dayOf(8, 9);
    const dom = SHAPES.dom, com = SHAPES.com;
    const sim = (a: number[], b: number[]) => { let x = 0, y = 0, z = 0; for (let i = 0; i < 24; i++) { x += a[i] * b[i]; y += a[i] ** 2; z += b[i] ** 2; } return x / Math.sqrt(y * z); };
    cases.push({
      id: 'CASE-105', key: 'S5', title: `Shop-hours load on a subsidised domestic service, ${c.id}`, sec: c.sec, entity: c.id, entityType: 'Consumer', day: det, hour: 12, severity: 'Low',
      category: 'Tariff / category misuse', agent: 'Billing agent', planted: true, lat: c.lat, lng: c.lng,
      summary: `Gruha Jyothi service ${c.id} draws power 10:00–21:00 six days a week and drops on Sundays, a commercial pattern.`,
      hyp0: { 'Commercial use on domestic tariff': 0.3, 'Work-from-home household': 0.35, 'Home business allowed under rules': 0.2, 'Meter / data error': 0.15 },
      steps: [
        { tool: 'load_shape_classifier', ask: `${c.id}, 30-day hourly profile`, result: `Similarity to commercial profile ${sim(com, com).toFixed(2)} vs domestic ${sim(com, dom).toFixed(2)}; Sunday consumption −64%.`, ev: [{ id: `EV-LS-${c.id}`, label: 'Profile match', value: 'Commercial 0.99 / Domestic 0.71' }], hyp: { 'Commercial use on domestic tariff': 0.5, 'Work-from-home household': 0.25, 'Home business allowed under rules': 0.15, 'Meter / data error': 0.1 } },
        { tool: 'meter_events', ask: `${c.meterId}`, result: 'No faults or tamper events; data is consistent.', ev: [{ id: `EV-MTR-${c.id}`, label: 'Events', value: 'None' }], hyp: { 'Commercial use on domestic tariff': 0.55, 'Work-from-home household': 0.27, 'Home business allowed under rules': 0.16, 'Meter / data error': 0.02 } },
        { tool: 'rag_search', ask: 'Tariff rules for home-based activity', result: 'Retrieved tariff order clauses: categorisation depends on verified premises use; data alone cannot decide.', ev: [{ id: 'DOC-TARIFF-CAT', label: 'Tariff category rules', value: 'Retrieved' }], hyp: { 'Commercial use on domestic tariff': 0.55, 'Work-from-home household': 0.27, 'Home business allowed under rules': 0.16, 'Meter / data error': 0.02 } },
      ],
      proposed: 'Inconclusive', truth: 'Suspected misconduct referral', truthNote: 'Planted: a small shop operating on a Gruha Jyothi domestic service.',
      action: 'Needs field verification of premises use before any re-categorisation. Agent deliberately does not decide.',
      exposure: { rs: 3 * 1350, basis: 'Indicative tariff difference over 3 months' },
      outputs: [{ type: 'Work order', text: `Premises-use verification at ${c.id}.` }],
    });
  }

  // ---------------------------------------------------------------- S6 counter diversion
  {
    const det = dayOf(9, 10); const ids: string[] = P.S6.ids; const pays = D.payments.filter(p => ids.includes(p.id));
    const firstTwo = pays.filter(p => p.day <= det - 1);
    const otherCounters = D.payments.filter(p => p.counter && p.counter !== P.S6.counter && p.counter.startsWith('COL-SMB') && p.settledDay !== null);
    cases.push({
      id: 'CASE-106', key: 'S6', title: `Counter receipts not reaching the bank, ${P.S6.counter}`, sec: 'SMB', entity: P.S6.counter, entityType: 'Counter', day: det, hour: 9, severity: 'High',
      category: 'Collection diversion / fake receipts', agent: 'Collections agent', planted: true, lat: 17.262, lng: 78.415,
      summary: `Cash receipts issued at ${P.S6.counter} since ${fmtDay(dayOf(9, 8))} are credited to consumer accounts but have no matching bank settlement after T+1.`,
      hyp0: { 'Collection diversion': 0.25, 'Bank posting delay': 0.4, 'Deposit slip mis-keyed': 0.25, 'Receipt reversal pending': 0.1 },
      steps: [
        { tool: 'settlement_match', ask: `${P.S6.counter} receipts vs bank file`, result: `${firstTwo.length} receipts (${rs(firstTwo.reduce((s, p) => s + p.amt, 0))}) unmatched after T+1. Other SMB counters: ${otherCounters.length} receipts, all settled.`, ev: firstTwo.slice(0, 2).map(p => ({ id: p.id, label: `Receipt ${rs(p.amt)}`, value: `issued ${fmtDay(p.day)}, unsettled` })), hyp: { 'Collection diversion': 0.4, 'Bank posting delay': 0.3, 'Deposit slip mis-keyed': 0.22, 'Receipt reversal pending': 0.08 } },
        { tool: 'bank_file_check', ask: 'Bank deposits for SMB cash collections', result: 'Bank shows deposits for COL-SMB-01 and -02 on time; nothing from -03 since 8 Sep. Not a bank-wide delay.', ev: [{ id: 'EV-BANK-SMB-0909', label: 'COL-SMB-03 deposits since 8 Sep', value: '₹0' }], hyp: { 'Collection diversion': 0.62, 'Bank posting delay': 0.08, 'Deposit slip mis-keyed': 0.24, 'Receipt reversal pending': 0.06 } },
        { tool: 'monitor (ongoing)', ask: 'Track until resolution', result: `By 26 Sep: ${P.S6.n} unsettled receipts, ${rs(P.S6.amt)}. No deposit slips submitted.`, ev: [{ id: 'EV-SET-COL-SMB-03', label: 'Unsettled total', value: rs(P.S6.amt) }], hyp: { 'Collection diversion': 0.82, 'Bank posting delay': 0.03, 'Deposit slip mis-keyed': 0.12, 'Receipt reversal pending': 0.03 } },
      ],
      proposed: 'Suspected misconduct referral', truth: 'Suspected misconduct referral', truthNote: 'Planted: 41 cash receipts at COL-SMB-03 never deposited.',
      action: 'Freeze the counter cash book, independent cash audit, and vigilance referral. Consumers hold valid receipts — do not chase them for payment.',
      exposure: { rs: P.S6.amt, basis: 'Sum of unsettled receipts' },
      outputs: [{ type: 'Payment reconciliation', text: `Hold ${P.S6.n} receipts in suspense; consumers remain credited.` }, { type: 'Work order', text: 'Cash audit at COL-SMB-03.' }],
    });
  }

  // ---------------------------------------------------------------- S7 fake payment links
  {
    const det = dayOf(10, 4); const tks = D.tickets.filter(t => P.S7.ids.includes(t.id));
    const base = D.tickets.filter(t => !t.past && t.type === 'Payment not reflected' && !P.S7.ids.includes(t.id)).length;
    const past = D.tickets.filter(t => t.past && /link/i.test(t.text));
    cases.push({
      id: 'CASE-107', key: 'S7', title: 'Spike in "paid via link, not reflected" complaints', sec: 'SMB', entity: 'Circle-wide', entityType: 'Area', day: det, hour: 18, severity: 'High',
      category: 'Digital bill-payment impersonation', agent: 'Complaints agent', planted: true, lat: 17.36, lng: 78.36,
      summary: `${tks.filter(t => t.day <= det).length} complaints in 2 days mention paying through an SMS or WhatsApp link. No matching transactions exist in any official gateway.`,
      hyp0: { 'Impersonation / fake payment links': 0.3, 'Official gateway outage': 0.4, 'Posting delay': 0.3 },
      steps: [
        { tool: 'complaint_cluster', ask: 'Payment complaints, last 7 days, semantic clusters', result: `Cluster of near-identical texts: "SMS said disconnection tonight, paid via link". Normal rate ≈${(base / 100).toFixed(1)}/day; now ${(tks.filter(t => t.day <= det).length / 2).toFixed(0)}/day.`, ev: tks.slice(0, 2).map(t => ({ id: t.id, label: 'Complaint', value: `"${t.text.slice(0, 48)}…"` })), hyp: { 'Impersonation / fake payment links': 0.5, 'Official gateway outage': 0.3, 'Posting delay': 0.2 } },
        { tool: 'gateway_lookup', ask: 'Amounts/dates in complaints vs UPI, BBPS and online gateway files', result: '0 of the complained payments exist in official gateway files; official gateways processed normal volumes.', ev: [{ id: 'EV-GW-0104', label: 'Matched transactions', value: '0' }], hyp: { 'Impersonation / fake payment links': 0.85, 'Official gateway outage': 0.05, 'Posting delay': 0.1 } },
        { tool: 'rag_search', ask: '"paid through link in SMS not reflected"', result: `${past.length} past tickets resolved as "Fake payment link (impersonation SMS)"; fix: consumer advisory + cyber-crime report.`, ev: past.slice(0, 1).map(t => ({ id: t.id, label: 'Past root cause', value: t.rootCause! })), hyp: { 'Impersonation / fake payment links': 0.9, 'Official gateway outage': 0.03, 'Posting delay': 0.07 } },
      ],
      proposed: 'Suspected misconduct referral', truth: 'Suspected misconduct referral', truthNote: 'Planted: 63 complaints 3–8 Oct from an impersonation SMS campaign. Consumers are victims.',
      action: 'Consumer awareness SMS from the official sender ID listing verified payment channels; report to cyber-crime cell; do not disconnect affected consumers while cases are reviewed.',
      exposure: { rs: 63 * 1100, basis: 'Consumer money lost to fake links (≈₹1,100 avg) — a consumer harm, not utility revenue' },
      outputs: [{ type: 'Consumer alert', text: 'Official SMS: "We never send payment links by SMS/WhatsApp. Pay only via official app, website, BBPS or counters."' }, { type: 'Work order', text: 'Hold disconnection for complainants pending review.' }],
    });
  }

  // ---------------------------------------------------------------- S8 unauthorized reconnection
  {
    const c = byId.get(P.S8.cid)!; const det = P.S8.resume; const used = avg(c.actual, det, det + 10);
    let tot = 0; for (let d = det; d < DAYS; d++) tot += c.actual[d];
    const wo = D.workOrders.find(w => w.cid === c.id)!;
    cases.push({
      id: 'CASE-108', key: 'S8', title: `Consumption after disconnection, ${c.id}`, sec: c.sec, entity: c.id, entityType: 'Consumer', day: det, hour: 19, severity: 'Medium',
      category: 'Unauthorized reconnection', agent: 'Meter health agent', planted: true, lat: c.lat, lng: c.lng,
      summary: `${c.id} was disconnected for arrears on ${fmtDay(P.S8.disc)}. Four days later the meter records load while its relay reports OPEN.`,
      hyp0: { 'Unauthorized reconnection / bypass of relay': 0.3, 'Approved reconnection not recorded': 0.35, 'Relay fault': 0.35 },
      steps: [
        { tool: 'work_orders', ask: `${c.id}`, result: `${wo.id}: "${wo.text}" No reconnection order, no payment received.`, ev: [{ id: wo.id, label: 'Disconnection', value: fmtDay(wo.day) }], hyp: { 'Unauthorized reconnection / bypass of relay': 0.45, 'Approved reconnection not recorded': 0.15, 'Relay fault': 0.4 } },
        { tool: 'meter_events', ask: `${c.meterId}`, result: `"Load detected while relay status = OPEN" at ${fmtDayHour(det, 19)}. ≈${used.toFixed(1)} kWh/day since.`, ev: [{ id: D.events.find(e => e.cid === c.id && e.type.startsWith('Load'))!.id, label: 'Relay-open load', value: fmtDayHour(det, 19) }], hyp: { 'Unauthorized reconnection / bypass of relay': 0.6, 'Approved reconnection not recorded': 0.1, 'Relay fault': 0.3 } },
        { tool: 'relay_diagnostics', ask: 'Relay self-test', result: 'Relay self-test passes; contacts confirmed open. Load is reaching the premises through another path, or the meter has been bypassed.', ev: [{ id: `EV-RLY-${c.meterId}`, label: 'Relay self-test', value: 'Pass (open)' }], hyp: { 'Unauthorized reconnection / bypass of relay': 0.82, 'Approved reconnection not recorded': 0.1, 'Relay fault': 0.08 } },
      ],
      proposed: 'Suspected misconduct referral', truth: 'Suspected misconduct referral', truthNote: 'Planted: supply restored without approval 4 days after disconnection.',
      action: 'Field verification of the service connection; reconcile work orders, field status and account history.',
      exposure: { kwh: tot, rs: tot * RATE, basis: 'Unbilled consumption since reconnection' },
      outputs: [{ type: 'Inspection order', text: `Verify service cable and meter at ${c.id}.` }],
    });
  }

  // ---------------------------------------------------------------- I1 genuine meter fault
  {
    const c = byId.get(P.I1.cid)!; const det = P.I1.from + 1; const ev = D.events.filter(e => e.cid === c.id);
    let lost = 0; for (let d = P.I1.from; d < DAYS; d++) lost += c.actual[d];
    cases.push({
      id: 'CASE-109', key: 'I1', title: `Register stopped at ${c.id}`, sec: c.sec, entity: c.id, entityType: 'Consumer', day: det, hour: 6, severity: 'Medium',
      category: 'Meter interference or bypass', agent: 'Meter health agent', planted: true, lat: c.lat, lng: c.lng,
      summary: `Meter ${c.meterId} reports zero consumption since ${fmtDay(P.I1.from)}.`,
      hyp0: { 'Meter interference': 0.3, 'Genuine meter fault': 0.3, 'Vacancy': 0.25, 'Comms / data gap': 0.15 },
      steps: [
        { tool: 'meter_events', ask: c.meterId, result: `${ev.length} "Self-diagnostic: metrology error" events; no tamper, magnet or cover-open events.`, ev: ev.map(e => ({ id: e.id, label: e.type, value: fmtDayHour(e.day, e.hour) })), hyp: { 'Meter interference': 0.12, 'Genuine meter fault': 0.62, 'Vacancy': 0.16, 'Comms / data gap': 0.1 } },
        { tool: 'comms_status', ask: c.meterId, result: 'Meter communicates every 15 minutes, so data is arriving — the register itself is not advancing.', ev: [{ id: `EV-COM-${c.meterId}`, label: 'Comms', value: 'Healthy' }], hyp: { 'Meter interference': 0.12, 'Genuine meter fault': 0.7, 'Vacancy': 0.16, 'Comms / data gap': 0.02 } },
        { tool: 'energy_balance', ask: `${c.dt} before/after`, result: `DT residual rose by ≈${(avg(c.actual, P.I1.from, P.I1.from + 5)).toFixed(0)} kWh/day, matching this home's normal use: the premises is occupied.`, ev: [{ id: `EV-EB-${c.dt}`, label: 'Residual increase', value: `${avg(c.actual, P.I1.from, P.I1.from + 5).toFixed(0)} kWh/day` }], hyp: { 'Meter interference': 0.1, 'Genuine meter fault': 0.86, 'Vacancy': 0.02, 'Comms / data gap': 0.02 } },
      ],
      proposed: 'Fault', truth: 'Fault', truthNote: 'Planted innocent case: genuine metrology failure. Not fraud.',
      action: 'Replace meter and test the removed meter in the lab. Bill the stopped period under the regulator-approved average method, not as a penalty.',
      exposure: { kwh: lost, rs: lost * RATE, basis: 'Recoverable through regulated average billing' },
      outputs: [{ type: 'Work order', text: `Meter replacement for ${c.id}; send old meter for lab test.` }, { type: 'Bill correction', text: 'Average-basis bill for the stopped period (draft, needs approval).' }],
    });
  }

  // ---------------------------------------------------------------- I2 rooftop solar
  {
    const c = byId.get(P.I2.cid)!; const det = P.I2.from + 3; const wo = D.workOrders.find(w => w.cid === c.id)!;
    const b = avg(c.actual, P.I2.from - 20, P.I2.from - 1), a = avg(c.actual, P.I2.from, det);
    cases.push({
      id: 'CASE-110', key: 'I2', title: `Net consumption down ${pct(1 - a / b, 0)}, ${c.id}`, sec: c.sec, entity: c.id, entityType: 'Consumer', day: det, hour: 13, severity: 'Low',
      category: 'Meter interference or bypass', agent: 'Meter health agent', planted: true, lat: c.lat, lng: c.lng,
      summary: `Recorded consumption at ${c.id} fell from ${b.toFixed(1)} to ${a.toFixed(1)} kWh/day.`,
      hyp0: { 'Meter interference': 0.35, 'Rooftop solar': 0.2, 'Vacancy': 0.25, 'Meter fault': 0.2 },
      steps: [
        { tool: 'work_orders', ask: c.id, result: `${wo.id} (${fmtDay(wo.day)}): "${wo.text}"`, ev: [{ id: wo.id, label: 'Net-meter commissioning', value: fmtDay(wo.day) }], hyp: { 'Meter interference': 0.08, 'Rooftop solar': 0.8, 'Vacancy': 0.06, 'Meter fault': 0.06 } },
        { tool: 'load_shape', ask: `${c.id} hourly`, result: 'Drop is concentrated 09:00–16:00 (solar hours); evening peak unchanged. Matches generation, not tampering.', ev: [{ id: `EV-LS-${c.id}`, label: 'Midday drop', value: 'Yes' }], hyp: { 'Meter interference': 0.03, 'Rooftop solar': 0.94, 'Vacancy': 0.01, 'Meter fault': 0.02 } },
      ],
      proposed: 'Legitimate change', truth: 'Legitimate change', truthNote: 'Planted innocent case: approved rooftop solar.',
      action: 'Close: no action. Update the consumer\'s category cluster to solar net-metered so it stops being compared with ordinary homes.',
      exposure: { rs: 0, basis: 'No loss' }, outputs: [{ type: 'Data fix', text: `Move ${c.id} to the solar net-metered cluster.` }],
    });
  }

  // ---------------------------------------------------------------- I3 vacancy
  {
    const c = byId.get(P.I3.cid)!; const det = P.I3.from + 4; const tk = D.tickets.find(t => t.cid === c.id && t.type === 'Account update')!;
    cases.push({
      id: 'CASE-111', key: 'I3', title: `Near-zero consumption, ${c.id}`, sec: c.sec, entity: c.id, entityType: 'Consumer', day: det, hour: 9, severity: 'Low',
      category: 'Meter interference or bypass', agent: 'Meter health agent', planted: true, lat: c.lat, lng: c.lng,
      summary: `${c.id} dropped to ≈0.4 kWh/day (fridge-level load) from ${fmtDay(P.I3.from)}.`,
      hyp0: { 'Meter bypass': 0.35, 'Vacancy': 0.35, 'Meter fault': 0.3 },
      steps: [
        { tool: 'rag_search', ask: `Tickets for ${c.id}`, result: `${tk.id} (${fmtDay(tk.day)}): "${tk.text}"`, ev: [{ id: tk.id, label: 'Consumer notice', value: fmtDay(tk.day) }], hyp: { 'Meter bypass': 0.12, 'Vacancy': 0.8, 'Meter fault': 0.08 } },
        { tool: 'energy_balance', ask: c.dt, result: 'DT residual unchanged: the energy is genuinely not being used anywhere on this DT.', ev: [{ id: `EV-EB-${c.dt}`, label: 'Residual change', value: '≈0' }], hyp: { 'Meter bypass': 0.03, 'Vacancy': 0.95, 'Meter fault': 0.02 } },
      ],
      proposed: 'Legitimate change', truth: 'Legitimate change', truthNote: 'Planted innocent case: flat vacated.',
      action: 'Close: no inspection needed. Re-check automatically when consumption resumes.', exposure: { rs: 0, basis: 'No loss' },
      outputs: [{ type: 'Monitoring', text: `Auto-close; alert again only if DT residual changes.` }],
    });
  }

  // ---------------------------------------------------------------- I4 posting delay
  {
    const det = dayOf(8, 16);
    cases.push({
      id: 'CASE-112', key: 'I4', title: `${P.I4.n} gateway payments not settled after T+1`, sec: 'GCB', entity: 'BBPS gateway', entityType: 'Gateway', day: det, hour: 10, severity: 'Medium',
      category: 'Collection diversion / fake receipts', agent: 'Collections agent', planted: true, lat: 17.42, lng: 78.37,
      summary: `Payments made through the BBPS gateway on 14–16 Aug (${rs(P.I4.amt)}) have not appeared in the bank settlement file.`,
      hyp0: { 'Collection diversion': 0.3, 'Gateway settlement delay': 0.45, 'Mis-allocation': 0.25 },
      steps: [
        { tool: 'settlement_match', ask: 'Unsettled by channel', result: 'All unsettled items are from one gateway, across all 6 sections and many counters: a channel-level pattern, not a person.', ev: [{ id: 'EV-SET-BBPS-0816', label: 'Unsettled items', value: `${P.I4.n} (one gateway)` }], hyp: { 'Collection diversion': 0.08, 'Gateway settlement delay': 0.8, 'Mis-allocation': 0.12 } },
        { tool: 'monitor (ongoing)', ask: 'Bank file 19 Aug', result: `All ${P.I4.n} payments settled on 19 Aug in one batch.`, ev: [{ id: 'EV-BANK-0819', label: 'Batch settlement', value: rs(P.I4.amt) }], hyp: { 'Collection diversion': 0.01, 'Gateway settlement delay': 0.98, 'Mis-allocation': 0.01 } },
      ],
      proposed: 'Payment issue', truth: 'Payment issue', truthNote: 'Planted innocent case: gateway batch settled late (T+3).',
      action: 'Close. Suppress arrears flags for these consumers during the delay; raise the SLA breach with the gateway.', exposure: { rs: 0, basis: 'Funds received late; no loss' },
      outputs: [{ type: 'Payment reconciliation', text: `${P.I4.n} payments matched on 19 Aug; no consumer marked in arrears.` }],
    });
  }

  // ---------------------------------------------------------------- I5 GIS mapping error
  {
    const det = dayOf(8, 4); const w = dtById.get(P.I5.wrongDt)!, r = dtById.get(P.I5.rightDt)!;
    const rw = residualRange(w, P.I5.from, det), rr = residualRange(r, P.I5.from, det);
    cases.push({
      id: 'CASE-113', key: 'I5', title: `Mirror-image residuals on ${P.I5.rightDt} and ${P.I5.wrongDt}`, sec: 'NSG', entity: P.I5.rightDt, entityType: 'DT', day: det, hour: 8, severity: 'Medium',
      category: 'Unauthorized connections / direct abstraction', agent: 'Loss agent', planted: true, lat: r.lat, lng: r.lng,
      summary: `${P.I5.rightDt} shows a +${pct(rr.pct, 0)} gap while neighbouring ${P.I5.wrongDt} shows ${pct(rw.pct, 0)} (more billed than supplied) since ${fmtDay(P.I5.from)}.`,
      hyp0: { 'Unauthorized tap': 0.4, 'GIS mapping error': 0.3, 'DT meter error': 0.3 },
      steps: [
        { tool: 'energy_balance', ask: 'Both DTs since 1 Aug', result: `Gaps cancel out: ${kwh(rr.res / (det - P.I5.from + 1))}/day missing on one, ${kwh(-rw.res / (det - P.I5.from + 1))}/day extra on the other. Theft cannot create a negative residual next door.`, ev: [{ id: `EV-EB-${r.id}`, label: `${r.id} residual`, value: pct(rr.pct) }, { id: `EV-EB-${w.id}`, label: `${w.id} residual`, value: pct(rw.pct) }], hyp: { 'Unauthorized tap': 0.08, 'GIS mapping error': 0.8, 'DT meter error': 0.12 } },
        { tool: 'gis_connectivity', ask: 'Topology change log', result: `GIS update on 31 Jul moved ${P.I5.cids.length} services from ${r.id} to ${w.id}; field network unchanged.`, ev: [{ id: 'EV-GIS-NSG-0731', label: 'Re-mapped services', value: `${P.I5.cids.length}` }], hyp: { 'Unauthorized tap': 0.02, 'GIS mapping error': 0.96, 'DT meter error': 0.02 } },
      ],
      proposed: 'Data defect', truth: 'Data defect', truthNote: 'Planted innocent case: 16 services mapped to the wrong DT in a GIS update.',
      action: 'Correct GIS mapping (versioned); no field inspection for theft. Re-run energy balance after the fix.', exposure: { rs: 0, basis: 'No revenue loss; data defect' },
      outputs: [{ type: 'Data fix', text: `Re-map ${P.I5.cids.length} services back to ${r.id}, effective 1 Aug.` }],
    });
  }

  // ---------------------------------------------------------------- claims for disconnected services
  {
    const det = dayOf(9, 3); const ids: string[] = P.CLAIM.disconnectedClaimed;
    const amt = D.claims.filter(c => ids.includes(c.cid)).reduce((s, c) => s + c.amount, 0);
    cases.push({
      id: 'CASE-114', key: 'CL', title: `Subsidy claimed for ${ids.length} disconnected services`, sec: 'MBD', entity: 'GJ claim file Aug', entityType: 'Area', day: det, hour: 12, severity: 'Medium',
      category: 'Subsidy / beneficiary misrepresentation', agent: 'Collections agent', planted: true, lat: 17.325, lng: 78.272,
      summary: `The August Gruha Jyothi claim includes ${ids.length} services that were disconnected on 20 Jul and issued no bill.`,
      hyp0: { 'Deliberate claim inflation': 0.3, 'Stale enrolment list': 0.5, 'Bill run error': 0.2 },
      steps: [
        { tool: 'claim_reconciliation', ask: 'Claims vs zero bills issued, Aug', result: `${ids.length} claims have no matching bill; all are in Moinabad and all disconnected on the same date.`, ev: [{ id: 'EV-CLM-AUG-MBD', label: 'Claims without bills', value: `${ids.length}` }], hyp: { 'Deliberate claim inflation': 0.25, 'Stale enrolment list': 0.6, 'Bill run error': 0.15 } },
        { tool: 'work_orders', ask: 'Disconnection reason', result: 'Consumer-requested disconnection (premises demolished); enrolment list never updated. No other services or users involved.', ev: [{ id: 'EV-WO-MBD-0720', label: 'Disconnections', value: `${ids.length} on 20 Jul` }], hyp: { 'Deliberate claim inflation': 0.08, 'Stale enrolment list': 0.88, 'Bill run error': 0.04 } },
      ],
      proposed: 'Data defect', truth: 'Data defect', truthNote: 'Planted: enrolment list not updated after disconnections; claims over-stated.',
      action: 'Withdraw the over-claimed amount in the next claim file and add a disconnection check before every claim.', exposure: { rs: amt, basis: 'Over-claimed subsidy, Aug + Sep' },
      outputs: [{ type: 'Subsidy claim correction', text: `Remove ${ids.length} services; adjust ${rs(amt)} in next claim.` }],
    });
  }

  cases.sort((a, b) => a.day * 24 + a.hour - (b.day * 24 + b.hour));

  // ---------------------------------------------------------------- alerts (incl. background noise)
  const R = rng(77);
  const alerts: Alert[] = cases.map(c => ({ id: 'AL-' + c.id.slice(5), day: c.day, hour: c.hour, sec: c.sec, sev: c.severity, title: c.title, caseId: c.id, source: c.agent }));
  const noise = ['DT meter interval gap (auto-filled)', 'AMI comms loss > 24 h', 'Duplicate reading uploaded', 'Late bill file from section', 'Voltage unbalance at DT'];
  for (let i = 0; i < 38; i++) {
    const s = SECTIONS[Math.floor(R() * 6)];
    alerts.push({ id: 'AL-N' + String(i + 1).padStart(3, '0'), day: Math.floor(R() * DAYS), hour: Math.floor(R() * 24), sec: s.code, sev: 'Low', title: `${noise[Math.floor(R() * noise.length)]} · ${s.name}`, source: 'Data quality' });
  }
  alerts.sort((a, b) => a.day * 24 + a.hour - (b.day * 24 + b.hour));
  return { cases, alerts };
}
