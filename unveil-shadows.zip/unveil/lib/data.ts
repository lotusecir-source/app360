// Synthetic data generator for the Unveil Shadows demo.
// Everything here is SYNTHETIC. Seeded, so every run produces identical data.

export const SEED = 20261016;
export const START = Date.UTC(2026, 6, 1); // 1 Jul 2026
export const DAYS = 107; // 1 Jul .. 15 Oct 2026
export const H = 24;

export function rng(seed: number) {
  let a = seed >>> 0;
  const f = () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return f;
}

export const dayDate = (d: number) => new Date(START + d * 864e5);
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const fmtDay = (d: number) => { const x = dayDate(d); return `${x.getUTCDate()} ${MON[x.getUTCMonth()]}`; };
export const fmtDayHour = (d: number, h: number) => `${fmtDay(d)}, ${String(h).padStart(2, '0')}:00`;
export const dayOf = (m: number, dd: number) => Math.round((Date.UTC(2026, m - 1, dd) - START) / 864e5);
export const MONTHS = [
  { key: 'Jul', label: 'July 2026', from: 0, to: 30, billed: true },
  { key: 'Aug', label: 'August 2026', from: 31, to: 61, billed: true },
  { key: 'Sep', label: 'September 2026', from: 62, to: 91, billed: true },
  { key: 'Oct', label: 'October 2026 (to 15th)', from: 92, to: 106, billed: false },
];
export const monthOfDay = (d: number) => MONTHS.findIndex(m => d >= m.from && d <= m.to);

export type Cat = 'GJ' | 'DOM' | 'COM' | 'LTI' | 'HTI' | 'AGR' | 'SOL' | 'TMP' | 'EVC';
export const CATS: Record<Cat, { label: string; base: number; shape: string; rate: number }> = {
  GJ: { label: 'Domestic · Gruha Jyothi', base: 4.9, shape: 'dom', rate: 0 },
  DOM: { label: 'Domestic · regular', base: 8.8, shape: 'dom', rate: 0 },
  COM: { label: 'Commercial', base: 19, shape: 'com', rate: 8.5 },
  LTI: { label: 'LT industrial', base: 62, shape: 'ind', rate: 7.7 },
  HTI: { label: 'HT industrial', base: 380, shape: 'flat', rate: 7.3 },
  AGR: { label: 'Agriculture', base: 26, shape: 'agr', rate: 0 },
  SOL: { label: 'Solar net-metered', base: 4.5, shape: 'sol', rate: 0 },
  TMP: { label: 'Temporary / construction', base: 34, shape: 'ind', rate: 11 },
  EVC: { label: 'EV charging', base: 85, shape: 'ev', rate: 6 },
};

function norm(a: number[]) { const s = a.reduce((x, y) => x + y, 0); return a.map(v => v / s); }
export const SHAPES: Record<string, number[]> = {
  dom: norm([2, 1.6, 1.4, 1.3, 1.4, 2, 3.4, 4.2, 3.8, 3, 2.6, 2.5, 2.6, 2.6, 2.5, 2.5, 2.8, 3.4, 4.6, 5.6, 5.8, 5.2, 4, 2.8]),
  com: norm([0.6, 0.5, 0.5, 0.5, 0.5, 0.6, 0.8, 1.4, 2.8, 4.2, 5, 5.2, 5.2, 5.2, 5.1, 5, 5, 5.1, 5.3, 5.3, 5, 4, 1.6, 0.8]),
  ind: norm([0.8, 0.8, 0.8, 0.8, 0.8, 0.9, 1.4, 3.5, 5.2, 5.6, 5.6, 5.6, 5, 5.5, 5.6, 5.6, 5.2, 4, 2, 1.2, 1, 0.9, 0.9, 0.8]),
  flat: norm([3.6, 3.6, 3.6, 3.6, 3.6, 3.7, 4, 4.4, 4.6, 4.7, 4.7, 4.7, 4.6, 4.7, 4.7, 4.7, 4.6, 4.5, 4.3, 4.1, 3.9, 3.8, 3.7, 3.6]),
  agr: norm([5, 5, 5, 5, 5, 4.6, 3, 2, 3.6, 4.6, 4.6, 4.6, 4.6, 4.6, 4.2, 3, 1.4, 1, 1, 1, 1.4, 3, 4.4, 5]),
  sol: norm([2.4, 2, 1.8, 1.6, 1.7, 2.3, 3.4, 3.4, 2, 0.8, 0.4, 0.3, 0.3, 0.3, 0.4, 0.8, 2, 3.8, 5.2, 6, 6.2, 5.6, 4.4, 3.2]),
  ev: norm([5.2, 5.2, 5.2, 5, 4.6, 3.6, 1.6, 0.8, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.8, 1, 1.6, 3, 4.4, 5, 5.2]),
};

export const SECTIONS = [
  { code: 'KKP', name: 'Kokapet', lat: 17.392, lng: 78.332, urban: true, coll: 0.93 },
  { code: 'NSG', name: 'Narsingi', lat: 17.383, lng: 78.366, urban: true, coll: 0.92 },
  { code: 'GCB', name: 'Gachibowli', lat: 17.443, lng: 78.350, urban: true, coll: 0.94 },
  { code: 'MKD', name: 'Manikonda', lat: 17.408, lng: 78.392, urban: true, coll: 0.9 },
  { code: 'SMB', name: 'Shamshabad', lat: 17.262, lng: 78.415, urban: true, coll: 0.84 },
  { code: 'MBD', name: 'Moinabad (rural)', lat: 17.325, lng: 78.272, urban: false, coll: 0.8 },
];

const URBAN_W: [Cat, number][] = [['GJ', 44], ['DOM', 30], ['COM', 13], ['LTI', 3], ['HTI', 0.6], ['SOL', 4], ['TMP', 3], ['EVC', 0.8], ['AGR', 1.6]];
const RURAL_W: [Cat, number][] = [['GJ', 40], ['DOM', 14], ['COM', 7], ['AGR', 35], ['LTI', 2], ['SOL', 1], ['TMP', 1]];

export interface Consumer {
  id: string; sec: string; dt: string; physDt: string; feeder: string; cat: Cat; meter: 'AMI' | 'Manual';
  meterId: string; kw: number; lat: number; lng: number; reader: string; rc?: string; house: string;
  actual: Float32Array; metered: Float32Array; note?: string;
}
export interface DT { id: string; sec: string; feeder: string; lat: number; lng: number; kva: number; tl: number; tlEst: number; inp: Float32Array; met: Float32Array; }
export interface Bill { cid: string; m: number; units: number; reported: number; amount: number; zero: boolean; gjEligible: boolean; status: string; }
export interface Payment { id: string; cid: string; m: number; amt: number; day: number; channel: string; counter?: string; settledDay: number | null; }
export interface Event { id: string; meterId: string; cid: string; day: number; hour: number; type: string; }
export interface WorkOrder { id: string; cid: string; day: number; type: string; text: string; }
export interface Ticket { id: string; day: number; sec: string; cid?: string; channel: string; type: string; text: string; status: string; rootCause?: string; fix?: string; past: boolean; }
export interface Claim { m: number; cid: string; amount: number; }

export function tariffDomestic(u: number) {
  // ILLUSTRATIVE slab tariff for the demo, not an official TGERC tariff.
  const slabs: [number, number][] = [[50, 1.95], [50, 3.1], [100, 4.8], [100, 7.7], [1e9, 9.0]];
  let r = u, amt = 0;
  for (const [w, p] of slabs) { const x = Math.min(r, w); amt += x * p; r -= x; if (r <= 0) break; }
  return Math.round(amt + 30);
}
export const GJ_CAP = 200;

export function generate() {
  const R = rng(SEED);
  const rand = (a: number, b: number) => a + (b - a) * R();
  const ri = (a: number, b: number) => Math.floor(rand(a, b + 1));
  const pick = <T,>(w: [T, number][]) => { const s = w.reduce((x, y) => x + y[1], 0); let r = R() * s; for (const [k, v] of w) { if ((r -= v) <= 0) return k; } return w[0][0]; };
  const gauss = () => { let u = 0; for (let i = 0; i < 6; i++) u += R(); return u - 3; };

  const season = new Float32Array(DAYS);
  for (let d = 0; d < DAYS; d++) {
    const m = monthOfDay(d);
    season[d] = [0.93, 0.9, 0.98, 1.03][m] * (1 + 0.03 * Math.sin(d / 5));
  }
  const agrSeason = (d: number) => [0.55, 0.6, 0.85, 1.05][monthOfDay(d)];
  const dow = (d: number) => dayDate(d).getUTCDay(); // 0 = Sunday

  const dts: DT[] = []; const consumers: Consumer[] = [];
  let sc = 100000;
  for (const s of SECTIONS) {
    for (let i = 1; i <= 10; i++) {
      const id = `${s.code}-DT-${String(i).padStart(2, '0')}`;
      const ang = (i / 10) * Math.PI * 2 + rand(-0.2, 0.2), rad = rand(0.006, 0.016);
      const dt: DT = { id, sec: s.code, feeder: `${s.code}-F${i <= 5 ? 1 : 2}`, lat: s.lat + Math.sin(ang) * rad, lng: s.lng + Math.cos(ang) * rad,
        kva: [100, 160, 250, 315][ri(0, 3)], tl: rand(0.055, 0.085), tlEst: 0, inp: new Float32Array(DAYS * H), met: new Float32Array(DAYS * H) };
      dt.tlEst = dt.tl + gauss() * 0.011;
      dts.push(dt);
      const n = s.urban ? ri(68, 92) : ri(45, 62);
      for (let k = 0; k < n; k++) {
        const cat = pick(s.urban ? URBAN_W : RURAL_W);
        const ami = R() < (s.urban ? 0.62 : 0.3) || cat === 'HTI' || cat === 'EVC' || cat === 'SOL';
        const c: Consumer = {
          id: `SC${sc++}`, sec: s.code, dt: id, physDt: id, feeder: dt.feeder, cat, meter: ami ? 'AMI' : 'Manual',
          meterId: `M${(sc * 7919) % 9000000 + 1000000}`, kw: cat === 'HTI' ? 150 : cat === 'LTI' ? 25 : cat === 'COM' ? 5 : cat === 'EVC' ? 30 : cat === 'TMP' ? 10 : 2,
          lat: dt.lat + gauss() * 0.0012, lng: dt.lng + gauss() * 0.0012, reader: `MR-${s.code}-${ri(1, 3)}`,
          rc: cat === 'GJ' ? 'RC-' + ((sc * 2654435761) >>> 0).toString(16).slice(0, 6).toUpperCase() : undefined,
          house: `H-${s.code}-${ri(1000, 9999)}`, actual: new Float32Array(DAYS), metered: null as any,
        };
        const base = CATS[cat].base * Math.exp(gauss() * 0.28);
        for (let d = 0; d < DAYS; d++) {
          let v = base * season[d] * (1 + gauss() * 0.06);
          if (cat === 'AGR') v = base * agrSeason(d) * (1 + gauss() * 0.1);
          if ((cat === 'COM' || cat === 'LTI') && dow(d) === 0) v *= 0.55;
          c.actual[d] = Math.max(0.2, v);
        }
        c.metered = c.actual;
        consumers.push(c);
      }
    }
  }
  const byId = new Map(consumers.map(c => [c.id, c]));
  const dtById = new Map(dts.map(d => [d.id, d]));
  const cons = (pred: (c: Consumer) => boolean) => consumers.filter(pred);
  const setMetered = (c: Consumer) => { if (c.metered === c.actual) c.metered = new Float32Array(c.actual); };

  const claims: Claim[] = [];
  const events: Event[] = []; const workOrders: WorkOrder[] = []; let evN = 1, woN = 1;
  const addEv = (c: Consumer, day: number, hour: number, type: string) => events.push({ id: `EV-${String(evN++).padStart(5, '0')}`, meterId: c.meterId, cid: c.id, day, hour, type });
  const addWO = (c: Consumer, day: number, type: string, text: string) => { const w = { id: `WO-${String(woN++).padStart(5, '0')}`, cid: c.id, day, type, text }; workOrders.push(w); return w; };

  // ------------------------------------------------------------------ planted scenarios
  const P: any = {};
  // S1: LV tap for e-rickshaw charging at KKP-DT-07 from 18 Sep, nightly 22:00-05:00, ~18 kW
  P.S1 = { dt: 'KKP-DT-07', from: dayOf(9, 18), kw: 18, hours: [22, 23, 0, 1, 2, 3, 4] };
  {
    const c = cons(x => x.dt === 'KKP-DT-07' && x.cat === 'DOM')[0];
    c.note = 'Registered connection near the charging yard'; P.S1.near = c.id; c.kw = 3;
  }
  // S2: magnetic tampering, commercial consumer, NSG
  {
    const c = cons(x => x.sec === 'NSG' && x.cat === 'COM' && x.meter === 'AMI')[2];
    P.S2 = { cid: c.id, from: dayOf(8, 20) };
    setMetered(c);
    for (let d = P.S2.from; d < DAYS; d++) c.metered[d] = c.actual[d] * 0.45;
    for (const d of [P.S2.from, P.S2.from + 1, P.S2.from + 6, P.S2.from + 13, P.S2.from + 27, P.S2.from + 41]) addEv(c, d, ri(9, 20), 'Magnet influence detected');
  }
  // S3: GJ threshold gaming by one meter reader, MKD DT-03/04, manual meters, Aug + Sep readings 191-199
  {
    const grp = cons(x => x.sec === 'MKD' && (x.dt === 'MKD-DT-03' || x.dt === 'MKD-DT-04') && x.cat === 'GJ').slice(0, 34);
    for (const c of grp) {
      c.meter = 'Manual'; c.reader = 'MR-MKD-7';
      for (let d = 31; d < DAYS; d++) c.actual[d] = c.actual[d] * (7.8 / 4.9);
    }
    P.S3 = { reader: 'MR-MKD-7', cids: grp.map(c => c.id) };
  }
  // S4: one household split across three GJ services sharing a ration card
  {
    const grp = cons(x => x.sec === 'GCB' && x.cat === 'GJ' && x.dt === 'GCB-DT-05').slice(0, 3);
    const rc = 'RC-7F3A21';
    for (const c of grp) { c.rc = rc; c.house = 'H-GCB-4471'; c.lat = grp[0].lat; c.lng = grp[0].lng; for (let d = 0; d < DAYS; d++) c.actual[d] = 5.1 * season[d] * (1 + gauss() * 0.05); }
    P.S4 = { rc, cids: grp.map(c => c.id) };
  }
  // S5: GJ domestic service used as a shop (commercial load shape), GCB
  {
    const c = cons(x => x.sec === 'GCB' && x.cat === 'GJ' && x.meter === 'AMI')[5];
    for (let d = 0; d < DAYS; d++) c.actual[d] = (dow(d) === 0 ? 2.4 : 6.6) * (1 + gauss() * 0.05);
    c.note = 'Load profile follows shop hours'; P.S5 = { cid: c.id };
  }
  // S8: unauthorized reconnection after disconnection for arrears, SMB
  {
    const c = cons(x => x.sec === 'SMB' && x.cat === 'DOM' && x.meter === 'AMI')[3];
    const d0 = dayOf(8, 10);
    addWO(c, d0, 'Disconnection', 'Disconnected for arrears of Rs 6,840 (3 bills unpaid). Seal applied.');
    addEv(c, d0, 11, 'Remote disconnect executed');
    for (let d = d0; d < d0 + 4; d++) c.actual[d] = 0;
    addEv(c, d0 + 4, 19, 'Load detected while relay status = OPEN');
    P.S8 = { cid: c.id, disc: d0, resume: d0 + 4 };
  }
  // I1: genuine meter fault - register frozen with self-diagnostic error
  {
    const c = cons(x => x.sec === 'KKP' && x.cat === 'DOM' && x.meter === 'AMI')[8];
    P.I1 = { cid: c.id, from: dayOf(8, 28) };
    setMetered(c);
    for (let d = P.I1.from; d < DAYS; d++) c.metered[d] = 0;
    addEv(c, P.I1.from, 3, 'Self-diagnostic: metrology error'); addEv(c, P.I1.from + 2, 3, 'Self-diagnostic: metrology error');
  }
  // I2: rooftop solar commissioned - legitimate drop
  {
    const c = cons(x => x.sec === 'NSG' && x.cat === 'DOM' && x.meter === 'AMI')[6];
    P.I2 = { cid: c.id, from: dayOf(8, 5) };
    addWO(c, dayOf(7, 30), 'Net-metering', 'Net-meter installed; 3 kWp rooftop solar commissioned and approved.');
    for (let d = P.I2.from; d < DAYS; d++) c.actual[d] *= 0.42;
  }
  // I3: vacant flat
  {
    const c = cons(x => x.sec === 'GCB' && x.cat === 'DOM' && x.meter === 'AMI')[9];
    P.I3 = { cid: c.id, from: dayOf(7, 25) };
    for (let d = P.I3.from; d < DAYS; d++) c.actual[d] = 0.35 + R() * 0.15;
  }
  // I5: GIS mapping error - 22 consumers physically on NSG-DT-05 recorded under NSG-DT-04 from 1 Aug
  {
    const grp = cons(x => x.dt === 'NSG-DT-05').slice(0, 16);
    for (const c of grp) c.dt = 'NSG-DT-04';
    P.I5 = { cids: grp.map(c => c.id), from: dayOf(8, 1), wrongDt: 'NSG-DT-04', rightDt: 'NSG-DT-05' };
  }

  // random genuine faults, comms loss, authorized cover-open
  const amiList = cons(c => c.meter === 'AMI');
  const commsLoss = new Set<string>();
  for (let i = 0; i < 6; i++) {
    const c = amiList[ri(0, amiList.length - 1)]; if (c.metered !== c.actual) continue;
    const d = ri(15, 100); addEv(c, d, ri(0, 23), 'Self-diagnostic: metrology error');
  }
  for (let i = 0; i < 70; i++) { const c = amiList[ri(0, amiList.length - 1)]; commsLoss.add(c.id); addEv(c, ri(60, 106), ri(0, 23), 'Communication loss > 24 h'); }
  for (let i = 0; i < 4; i++) {
    const c = amiList[ri(0, amiList.length - 1)]; const d = ri(20, 100);
    addWO(c, d, 'Meter maintenance', 'Scheduled terminal inspection, seal replaced by lineman.');
    addEv(c, d, 11, 'Terminal cover opened');
  }

  const disconnectedClaimed = cons(x => x.cat === 'GJ' && x.sec === 'MBD').slice(0, 9).map(c => c.id);
  for (const cid of disconnectedClaimed) {
    const c = byId.get(cid)!;
    addWO(c, dayOf(7, 20), 'Disconnection', 'Service disconnected at consumer request (premises demolished).');
    for (let d = dayOf(7, 20); d < DAYS; d++) c.actual[d] = 0;
  }
  P.CLAIM = { disconnectedClaimed };
  const discSet = new Set(disconnectedClaimed);

  // ------------------------------------------------------------------ DT hourly energy
  for (const c of consumers) {
    const shape = SHAPES[CATS[c.cat].shape];
    const isShop = P.S5 && c.id === P.S5.cid;
    const sh = isShop ? SHAPES.com : shape;
    const phys = dtById.get(c.physDt)!;
    for (let d = 0; d < DAYS; d++) {
      const a = c.actual[d];
      for (let h = 0; h < H; h++) phys.inp[d * H + h] += a * sh[h];
    }
  }
  for (const dt of dts) for (let d = 0; d < DAYS; d++) { const dn = gauss() * 0.012; for (let h = 0; h < H; h++) { const i = d * H + h; dt.inp[i] = dt.inp[i] * (1 + dt.tl) * (1 + dn + gauss() * 0.02); } }
  { // S1 tap
    const dt = dtById.get(P.S1.dt)!;
    for (let d = P.S1.from; d < DAYS; d++) for (const h of P.S1.hours) {
      const dd = h < 12 ? d + 1 : d; if (dd >= DAYS) continue;
      dt.inp[dd * H + h] += P.S1.kw * (0.85 + R() * 0.3);
    }
  }

  // ------------------------------------------------------------------ billing (Jul, Aug, Sep)
  const bills: Bill[] = [];
  const reportedUnits = (c: Consumer, m: number) => {
    const M = MONTHS[m]; let u = 0; for (let d = M.from; d <= M.to; d++) u += c.metered[d];
    if (P.S3.cids.includes(c.id) && (m === 1 || m === 2)) return ri(191, 199);
    return Math.round(u);
  };
  for (const c of consumers) for (let m = 0; m < 3; m++) {
    if (discSet.has(c.id) && m >= 1) continue;
    const M = MONTHS[m]; let act = 0; for (let d = M.from; d <= M.to; d++) act += c.actual[d];
    const rep = reportedUnits(c, m);
    let amount = 0, zero = false, gjEligible = false;
    if (c.cat === 'GJ') { gjEligible = rep <= GJ_CAP; zero = gjEligible; amount = zero ? 0 : tariffDomestic(rep); }
    else if (c.cat === 'DOM' || c.cat === 'SOL') amount = tariffDomestic(rep);
    else if (c.cat === 'AGR') { amount = 0; zero = true; }
    else amount = Math.round(rep * CATS[c.cat].rate + c.kw * 60);
    bills.push({ cid: c.id, m, units: Math.round(act), reported: rep, amount, zero, gjEligible, status: 'Issued' });
  }
  // metered DT sums: AMI = metered; Manual = billed units spread (Oct = Sep daily average estimate)
  const billByKey = new Map(bills.map(b => [`${b.cid}|${b.m}`, b]));
  const i5 = new Set<string>(P.I5.cids);
  for (const c of consumers) {
    const dtNew = dtById.get(c.dt)!, dtOld = dtById.get(c.physDt)!;
    const sh = (P.S5 && c.id === P.S5.cid) ? SHAPES.com : SHAPES[CATS[c.cat].shape];
    for (let d = 0; d < DAYS; d++) {
      let v = c.metered[d];
      if (c.meter === 'Manual') {
        const m = monthOfDay(d);
        if (m === 3 && !P.S3.cids.includes(c.id)) v = c.actual[d] * (1 + gauss() * 0.04); // Oct provisional: peer-profile estimate
        else { const M = MONTHS[Math.min(m, 2)]; const b = billByKey.get(`${c.id}|${Math.min(m, 2)}`); v = b ? b.reported / (M.to - M.from + 1) : 0; }
      }
      const dt = (i5.has(c.id) && d < P.I5.from) ? dtOld : dtNew;
      for (let h = 0; h < H; h++) dt.met[d * H + h] += v * sh[h];
    }
  }

  // ------------------------------------------------------------------ payments + settlement
  const payments: Payment[] = []; let pN = 1;
  const secColl = new Map(SECTIONS.map(s => [s.code, s.coll]));
  const counters: Record<string, string[]> = {}; for (const s of SECTIONS) counters[s.code] = [`COL-${s.code}-01`, `COL-${s.code}-02`, `COL-${s.code}-03`];
  const unpaid = new Map<string, number>();
  for (const b of bills) {
    if (b.amount <= 0) continue;
    const c = byId.get(b.cid)!;
    const billDay = MONTHS[b.m].to + 3;
    let p = secColl.get(c.sec)!; if (P.S8 && c.id === P.S8.cid) p = 0;
    if (R() > p) { unpaid.set(c.id, (unpaid.get(c.id) || 0) + b.amount); continue; }
    const day = Math.min(DAYS - 1, billDay + ri(1, 24));
    const r = R(); const channel = r < 0.55 ? 'UPI / online' : r < 0.7 ? 'BBPS gateway' : 'Counter (cash)';
    const pay: Payment = { id: `PAY-${String(pN++).padStart(6, '0')}`, cid: c.id, m: b.m, amt: b.amount, day, channel, settledDay: day + 1 };
    if (channel === 'Counter (cash)') pay.counter = counters[c.sec][ri(0, 2)];
    payments.push(pay);
  }
  // I4: BBPS gateway batch delay 14-16 Aug
  const i4 = payments.filter(p => p.channel === 'BBPS gateway' && p.day >= dayOf(8, 14) && p.day <= dayOf(8, 16));
  for (const p of i4) p.settledDay = dayOf(8, 19);
  P.I4 = { n: i4.length, amt: i4.reduce((a, p) => a + p.amt, 0), ids: i4.map(p => p.id) };
  // S6: counter diversion at COL-SMB-03, 8-26 Sep: receipts issued, never settled
  {
    const cands = consumers.filter(c => c.sec === 'SMB' && (c.cat === 'DOM' || c.cat === 'GJ'));
    const list: Payment[] = [];
    let k = 0;
    for (const c of cands) {
      const b = billByKey.get(`${c.id}|1`); if (!b || b.amount <= 0 || k >= 41) continue;
      const day = dayOf(9, 8) + Math.floor((k * 18) / 41);
      const pay: Payment = { id: `PAY-${String(pN++).padStart(6, '0')}`, cid: c.id, m: 1, amt: b.amount, day, channel: 'Counter (cash)', counter: 'COL-SMB-03', settledDay: null };
      payments.push(pay); list.push(pay); unpaid.delete(c.id); k++;
    }
    P.S6 = { counter: 'COL-SMB-03', n: list.length, amt: list.reduce((a, p) => a + p.amt, 0), ids: list.map(p => p.id) };
  }

  // ------------------------------------------------------------------ Gruha Jyothi subsidy claims
  for (const b of bills) {
    const c = byId.get(b.cid)!;
    if (c.cat === 'GJ' && b.zero) claims.push({ m: b.m, cid: b.cid, amount: tariffDomestic(b.reported) });
  }
  for (const cid of disconnectedClaimed) for (const m of [1, 2]) claims.push({ m, cid, amount: tariffDomestic(140) });


  // ------------------------------------------------------------------ complaints / tickets
  const T: Ticket[] = []; let tN = 1;
  const TT = [
    { type: 'High bill', text: ['Bill amount suddenly very high this month', 'Received a bill much higher than usual, no change in usage', 'Excess billing, please check meter reading'], rc: [['Estimated reading carried over after door-lock', 'Bill revised on actual reading'], ['Wrong multiplication factor after meter exchange', 'MF corrected and bill revised'], ['Genuine usage increase (AC in summer)', 'Explained usage to consumer']] },
    { type: 'Meter not working', text: ['Meter display blank', 'Meter not showing reading, display off', 'Meter stopped recording'], rc: [['Metrology fault in meter', 'Meter replaced and tested'], ['Display failure, register OK', 'Meter replaced']] },
    { type: 'Voltage fluctuation', text: ['Low voltage in the evening, fans running slow', 'Frequent voltage fluctuation in our lane', 'Voltage drops every night'], rc: [['DT overloaded at evening peak', 'Load balanced across phases'], ['Loose neutral connection at pole', 'Neutral tightened']] },
    { type: 'No supply', text: ['No power supply since morning', 'Power cut in our street for hours', 'Supply failed in our building'], rc: [['LT fuse blown at DT', 'Fuse replaced'], ['Cable fault after rain', 'Cable jointed']] },
    { type: 'Payment not reflected', text: ['Paid the bill online but payment not reflected', 'Payment made at counter not updated in account', 'Paid via UPI, still showing due'], rc: [['Gateway settlement delay', 'Posted after bank file received'], ['Payment posted to wrong service number', 'Reallocated to correct account']] },
    { type: 'Zero bill not received', text: ['Gruha Jyothi zero bill not applied though usage below 200 units', 'Applied for Gruha Jyothi but still getting bill', 'Zero bill stopped this month'], rc: [['Aadhaar not linked to service number', 'Linkage completed, bill revised'], ['Usage crossed 200 units', 'Explained eligibility rule'], ['White ration card not linked', 'Consumer advised to link card']] },
    { type: 'New connection delay', text: ['Applied for new connection, not yet released', 'New meter not installed after payment'], rc: [['Meter stock shortage', 'Meter allotted and installed']] },
    { type: 'Illegal connection report', text: ['Someone is drawing power directly from the line near our street', 'Illegal hooking seen on the pole at night'], rc: [['Unauthorized tap found on inspection', 'Tap removed, case booked under Sec 135']] },
  ];
  // past tickets (Jan-Jun 2026) with root causes - for RAG
  for (let i = 0; i < 360; i++) {
    const t = TT[ri(0, TT.length - 1)]; const rc = t.rc[ri(0, t.rc.length - 1)]; const s = SECTIONS[ri(0, 5)];
    T.push({ id: `TKT-${String(tN++).padStart(5, '0')}`, day: -ri(10, 180), sec: s.code, channel: ['IVR', 'App', 'Social', 'Walk-in'][ri(0, 3)], type: t.type, text: t.text[ri(0, t.text.length - 1)], status: 'Closed', rootCause: rc[0], fix: rc[1], past: true });
  }
  // a few historical "payment link" scam tickets to help RAG
  for (let i = 0; i < 4; i++) T.push({ id: `TKT-${String(tN++).padStart(5, '0')}`, day: -ri(20, 150), sec: SECTIONS[ri(0, 5)].code, channel: 'IVR', type: 'Payment not reflected', text: 'Got SMS saying power will be cut tonight, paid through the link in SMS, payment not reflected', status: 'Closed', rootCause: 'Fake payment link (impersonation SMS); money went to unofficial UPI ID', fix: 'Consumer advised; cyber-crime report; awareness SMS sent', past: true });
  // current tickets
  for (let i = 0; i < 210; i++) {
    const t = TT[ri(0, TT.length - 2)]; const s = SECTIONS[ri(0, 5)]; const d = ri(0, DAYS - 1);
    const sc2 = consumers[ri(0, consumers.length - 1)];
    T.push({ id: `TKT-${String(tN++).padStart(5, '0')}`, day: d, sec: s.code, cid: sc2.id, channel: ['IVR', 'App', 'Social', 'Walk-in'][ri(0, 3)], type: t.type, text: t.text[ri(0, t.text.length - 1)], status: d < 95 ? 'Closed' : 'Open', past: false });
  }
  // S7: fake payment-link spike 3-8 Oct
  const s7 = [] as string[];
  const s7text = ['Received SMS that power will be disconnected tonight, paid using the link, not reflected', 'Paid bill through link sent on WhatsApp, payment not showing', 'Paid via UPI link in SMS from electricity office, still showing due', 'SMS said bill pending disconnection today, paid via link, money gone'];
  for (let i = 0; i < 63; i++) {
    const s = SECTIONS[[0, 1, 2, 3, 4, 4, 3][ri(0, 6)]]; const d = dayOf(10, 3) + ri(0, 5);
    const id = `TKT-${String(tN++).padStart(5, '0')}`; s7.push(id);
    T.push({ id, day: d, sec: s.code, cid: consumers[ri(0, consumers.length - 1)].id, channel: ['IVR', 'App', 'Social'][ri(0, 2)], type: 'Payment not reflected', text: s7text[ri(0, 3)], status: 'Open', past: false });
  }
  P.S7 = { ids: s7 };
  // illegal connection report near KKP-DT-07 (supporting signal)
  T.push({ id: `TKT-${String(tN++).padStart(5, '0')}`, day: dayOf(9, 24), sec: 'KKP', channel: 'Social', type: 'Illegal connection report', text: 'Many e-rickshaws charging at night in the open yard near the pole, wires hanging', status: 'Open', past: false });
  // vacancy request
  T.push({ id: `TKT-${String(tN++).padStart(5, '0')}`, day: dayOf(7, 26), sec: 'GCB', cid: P.I3.cid, channel: 'App', type: 'Account update', text: 'Flat vacated, tenant moved out. Please note house is locked till new tenant.', status: 'Closed', past: false });

  return { consumers, dts, bills, payments, events, workOrders, tickets: T, claims, P, byId, dtById, unpaid, commsLoss, billByKey };
}

export type Data = ReturnType<typeof generate>;

// helpers
export function dtDaily(dt: DT, which: 'inp' | 'met', d: number) { let s = 0; for (let h = 0; h < H; h++) s += dt[which][d * H + h]; return s; }
export function residual(dt: DT, d: number, h?: number) {
  if (h === undefined) { const i = dtDaily(dt, 'inp', d), m = dtDaily(dt, 'met', d); return { inp: i, met: m, res: i - m * (1 + dt.tlEst), pct: (i - m * (1 + dt.tlEst)) / i }; }
  const i = dt.inp[d * H + h], m = dt.met[d * H + h]; return { inp: i, met: m, res: i - m * (1 + dt.tlEst), pct: (i - m * (1 + dt.tlEst)) / i };
}
export function residualRange(dt: DT, d0: number, d1: number) {
  let i = 0, m = 0; for (let d = d0; d <= d1; d++) { i += dtDaily(dt, 'inp', d); m += dtDaily(dt, 'met', d); }
  return { inp: i, met: m, res: i - m * (1 + dt.tlEst), pct: (i - m * (1 + dt.tlEst)) / i };
}
