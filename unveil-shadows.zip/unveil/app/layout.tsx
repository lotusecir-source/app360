import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Unveil Shadows · Lotus Cyber Security',
  description: 'Agentic AI revenue assurance for electricity distribution: loss detection, meter health, billing integrity and subsidy-aware collections.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
