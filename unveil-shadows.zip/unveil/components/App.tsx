'use client';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { generate, DAYS, H, SECTIONS, CATS, Cat, MONTHS, fmtDay, fmtDayHour, residual, residualRange, dtDaily, GJ_CAP, dayOf } from '@/lib/data';
import { buildCases, Case, rs } from '@/lib/cases';
import { buildIndex } from '@/lib/rag';
import { LineChart, Heatmap, Histogram, Bars } from './charts';
import { downloadAll } from '@/lib/csv';
import Dashboard, { usePrecomputed, DashHeader, ClockBar, DashFooter } from './Dashboard';

type View = 'live' | 'map' | 'alerts' | 'cases' | 'balance' | 'gj' | 'health' | 'tickets' | 'outputs' | 'score' | 'data';
const NAV: { id: View; label: string; hint: string }[] = [
  { id: 'live', label: 'Live dashboard', hint: 'Real-time metrics' },
  { id: 'map', label: 'Command map', hint: 'GIS view of loss and risk' },
  { id: 'alerts', label: 'Live alerts', hint: 'Replay of the stream' },
  { id: 'cases', label: 'Investigations', hint: 'Agent reasoning + approval' },
  { id: 'balance', label: 'Energy balance', hint: 'Feeder / DT residuals' },
  { id: 'gj', label: 'Gruha Jyothi', hint: 'Subsidy-aware collections' },
  { id: 'health', label: 'Meter health', hint: 'Fault vs tamper' },
  { id: 'tickets', label: 'Tickets + AI RAG', hint: 'Root cause from history' },
  { id: 'outputs', label: 'Outputs', hint: 'Bills, payments, actions' },
  { id: 'score', label: 'Scorecard', hint: 'Planted vs found' },
  { id: 'data', label: 'Data + downloads', hint: 'CSV export' },
];
const pct = (x: number, d = 1) => `${(x * 100).toFixed(d)}%`;
const secName = (c: string) => SECTIONS.find(s => s.code === c)?.name || c;
const OUTCOME_TONE: Record<string, string> = { 'Suspected misconduct referral': 'red', Fault: 'amber', 'Data defect': 'blue', 'Billing error': 'amber', 'Payment issue': 'blue', 'Legitimate change': 'green', Inconclusive: 'grey' };

function useStored<T>(key: string, init: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(init);
  useEffect(() => { try { const s = localStorage.getItem(key); if (s) setV(JSON.parse(s)); } catch { } }, [key]);
  return [v, (x: T) => { setV(x); try { localStorage.setItem(key, JSON.stringify(x)); } catch { } }];
}

export default function App() {
  const [ready, setReady] = useState(false);
  const store = useRef<any>(null);
  useEffect(() => { setTimeout(() => { const D = generate(); const C = buildCases(D); const idx = buildIndex(D.tickets.filter(t => t.past)); store.current = { D, ...C, idx }; setReady(true); }, 30); }, []);
  if (!ready) return <div className="loading"><div className="spinner" /><p>Loading circle data · 1 Jul – 15 Oct 2026 · ~4,500 services · 60 DTs</p></div>;
  return <Main {...store.current} />;
}

function Main({ D, cases, alerts, idx }: any) {
  const [view, setViewRaw] = useState<View>('live');
  const VIEWS: View[] = ['live', 'map', 'alerts', 'cases', 'balance', 'gj', 'health', 'tickets', 'outputs', 'score', 'data'];
  const setView = (v: View) => {
    setViewRaw(v);
    try { if (location.hash.slice(1) !== v) history.pushState(null, '', v === 'live' ? location.pathname : '#' + v); } catch { }
    try { window.scrollTo({ top: 0, behavior: 'auto' }); } catch { }
  };
  useEffect(() => {
    const read = () => { const h = (location.hash || '').slice(1) as View; setViewRaw(VIEWS.includes(h) ? h : 'live'); };
    read(); window.addEventListener('popstate', read); window.addEventListener('hashchange', read);
    (window as any).__setView = (v: View) => setViewRaw(v);
    return () => { window.removeEventListener('popstate', read); window.removeEventListener('hashchange', read); };
  }, []);
  const LIVE_START = dayOf(10, 14) * H + 18;
  const [t, setT] = useState(LIVE_START); // sim time in hours
  const [frac, setFrac] = useState(0);
  const [live, setLive] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [playing, setPlaying] = useState(false);
  const P = usePrecomputed(D);
  useEffect(() => {
    if (!live) return;
    const iv = setInterval(() => {
      setFrac(f => {
        const nf = f + speed / 12;
        if (nf >= 1) { setT(x => (x >= DAYS * H - 2 ? dayOf(10, 13) * H + 6 : x + 1)); return nf - 1; }
        return nf;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [live, speed]);
  const [sel, setSel] = useState<string | null>(null);
  const [dtSel, setDtSel] = useState('KKP-DT-07');
  const [decisions, setDecisions] = useStored<Record<string, string>>('unveil-decisions', {});
  const day = Math.floor(t / H), hour = t % H;
  useEffect(() => { if (!playing) return; const iv = setInterval(() => setT(x => { if (x >= DAYS * H - 1) { setPlaying(false); return x; } return Math.min(DAYS * H - 1, x + 6); }), 120); return () => clearInterval(iv); }, [playing]);
  const visibleCases: Case[] = cases.filter((c: Case) => c.day * H + c.hour <= t);
  const visibleAlerts = alerts.filter((a: any) => a.day * H + a.hour <= t);
  const openCase = (id: string) => { setSel(id); setView('cases'); };
  const openDt = (id: string) => { setDtSel(id); setView('balance'); };
  const pending = visibleCases.filter(c => !decisions[c.id]).length;
  const tf = t + frac;
  const ctx = { D, P, tf, live, setLive, speed, setSpeed, cases, alerts, idx, t, day, hour, visibleCases, visibleAlerts, openCase, openDt, decisions, setDecisions, sel, setSel, dtSel, setDtSel, setView };

  const TITLES: Record<string, string> = { live: 'Revenue assurance', map: 'Command map', alerts: 'Live alerts', cases: 'Investigations', balance: 'Energy balance', gj: 'Gruha Jyothi collections', health: 'Meter health', tickets: 'Tickets + AI RAG', outputs: 'Outputs', score: 'Scorecard', data: 'Data + downloads' };
  return (
    <div className="dash">
      <DashHeader view={view} setView={setView} live={live} setLive={(v: boolean) => { setPlaying(false); setLive(v); }} pending={pending} title={TITLES[view]} />
      <ClockBar tf={tf} live={live} speed={speed} setSpeed={setSpeed}>
        {view !== 'live' && <div className="dreplay">
          <button className="play" onClick={() => { setLive(false); setFrac(0); if (t >= DAYS * H - 1) setT(dayOf(9, 15) * H); setPlaying(!playing); }} aria-label={playing ? 'Pause replay' : 'Play replay'}>{playing ? '❚❚' : '▶'}</button>
          <div className="slider"><label>Replay up to <b>{fmtDayHour(day, hour)}</b></label>
            <input type="range" min={0} max={DAYS * H - 1} value={t} onChange={e => { setPlaying(false); setLive(false); setFrac(0); setT(+e.target.value); }} aria-label="Replay time" />
            <div className="months">{MONTHS.map(m => <span key={m.key} style={{ left: `${(m.from / DAYS) * 100}%` }}>{m.key}</span>)}</div>
          </div>
          <button className="ghost" onClick={() => { setPlaying(false); setLive(false); setFrac(0); setT(DAYS * H - 1); }}>End</button>
        </div>}
      </ClockBar>
      {view === 'live' ? <Dashboard {...ctx} /> : <section className="view">
        {view === 'map' && <MapView {...ctx} />}
        {view === 'alerts' && <AlertsView {...ctx} />}
        {view === 'cases' && <CasesView {...ctx} />}
        {view === 'balance' && <BalanceView {...ctx} />}
        {view === 'gj' && <GJView {...ctx} />}
        {view === 'health' && <HealthView {...ctx} />}
        {view === 'tickets' && <TicketsView {...ctx} />}
        {view === 'outputs' && <OutputsView {...ctx} />}
        {view === 'score' && <ScoreView {...ctx} />}
        {view === 'data' && <DataView {...ctx} />}
      </section>}
      <DashFooter setView={setView} />
    </div>
  );
}

const Title = ({ k, t, s }: { k: string; t: string; s?: string }) => <div className="vtitle"><span className="kicker">{k}</span><h1>{t}</h1>{s && <p>{s}</p>}</div>;
const Kpi = ({ v, l, tone }: { v: string; l: string; tone?: string }) => <div className={`kpi ${tone || ''}`}><span>{tone && <i className="tdot" />}{l}</span><b>{v}</b></div>;

// ------------------------------------------------------------------ MAP
function MapView({ D, day, visibleCases, openCase, openDt }: any) {
  const [cat, setCat] = useState<Cat | 'ALL'>('ALL');
  const d0 = Math.max(0, day - 6);
  const res = useMemo(() => new Map(D.dts.map((dt: any) => [dt.id, residualRange(dt, d0, day)])), [D, d0, day]);
  const lat0 = 17.22, lat1 = 17.475, lng0 = 78.235, lng1 = 78.45, W = 640, Hh = 640 * (lat1 - lat0) / (lng1 - lng0) * 1.0;
  const X = (lng: number) => ((lng - lng0) / (lng1 - lng0)) * W, Y = (lat: number) => (1 - (lat - lat0) / (lat1 - lat0)) * Hh;
  const color = (p: number) => p > 0.08 ? 'var(--red)' : p > 0.035 ? 'var(--amber)' : p < -0.04 ? 'var(--blue)' : 'var(--green)';
  let inp = 0, met = 0; D.dts.forEach((dt: any) => { const r: any = res.get(dt.id); inp += r.inp; met += r.met * (1 + dt.tlEst); });
  const top = [...D.dts].sort((a: any, b: any) => (res.get(b.id) as any).pct - (res.get(a.id) as any).pct).slice(0, 7);
  const cats = Object.keys(CATS) as Cat[];
  const counts = useMemo(() => { const m: any = {}; D.consumers.forEach((c: any) => m[c.cat] = (m[c.cat] || 0) + 1); return m; }, [D]);
  const open = visibleCases.filter((c: Case) => c.planted);
  return (
    <>
      <Title k="Command map" t="Where is the energy-to-cash chain breaking?" s={`Distribution transformers coloured by unaccounted energy over the 7 days to ${fmtDay(day)}, after expected technical loss.`} />
      <div className="kpis">
        <Kpi v={`${(inp / 1000).toFixed(0)} MWh`} l="Energy into DTs (7 days)" />
        <Kpi v={pct((inp - met) / inp, 2)} l="Unaccounted after technical loss" tone={(inp - met) / inp > 0.01 ? 'amber' : ''} />
        <Kpi v={String(open.length)} l="Investigations opened" />
        <Kpi v={String(open.filter((c: Case) => c.severity === 'High').length)} l="High severity" tone="red" />
        <Kpi v={D.consumers.length.toLocaleString('en-IN')} l="Services monitored" />
      </div>
      <div className="grid2 mapgrid">
        <div className="card">
          <div className="chips">
            <button className={cat === 'ALL' ? 'on' : ''} onClick={() => setCat('ALL')}>All categories</button>
            {cats.map(c => <button key={c} className={cat === c ? 'on' : ''} onClick={() => setCat(c)}>{CATS[c].label} <small>{counts[c]}</small></button>)}
          </div>
          <svg viewBox={`0 0 ${W} ${Hh}`} className="map" role="img" aria-label="Map of distribution transformers">
            <rect x={0} y={0} width={W} height={Hh} className="mapbg" rx={10} />
            <path d={`M ${X(78.25)} ${Y(17.29)} Q ${X(78.33)} ${Y(17.36)} ${X(78.44)} ${Y(17.4)}`} className="road" />
            <path d={`M ${X(78.33)} ${Y(17.47)} Q ${X(78.37)} ${Y(17.33)} ${X(78.42)} ${Y(17.23)}`} className="road" />
            {SECTIONS.map(s => <circle key={s.code} cx={X(s.lng)} cy={Y(s.lat)} r={58} className="secring" />)}
            {cat !== 'ALL' && D.consumers.filter((c: any) => c.cat === cat).map((c: any) => <circle key={c.id} cx={X(c.lng)} cy={Y(c.lat)} r={1.8} className="cdot" />)}
            {D.dts.map((dt: any) => { const r: any = res.get(dt.id); return <g key={dt.id} className="dt" onClick={() => openDt(dt.id)}><circle cx={X(dt.lng)} cy={Y(dt.lat)} r={6 + Math.min(10, Math.abs(r.pct) * 80)} fill={color(r.pct)} fillOpacity={0.85} /><title>{`${dt.id} · ${pct(r.pct)} unaccounted (7 days)`}</title></g>; })}
            {open.map((c: Case) => <g key={c.id} className="pin" onClick={() => openCase(c.id)}><path d={`M ${X(c.lng)} ${Y(c.lat) - 4} l -6 -12 a 7 7 0 1 1 12 0 z`} /><title>{c.title}</title></g>)}
            {SECTIONS.map(s => <text key={'l' + s.code} x={X(s.lng)} y={Y(s.lat) - 66} className="seclabel" textAnchor="middle">{s.name}</text>)}
          </svg>
          <div className="legend"><span><i style={{ background: 'var(--green)' }} />normal</span><span><i style={{ background: 'var(--amber)' }} />3.5–8%</span><span><i style={{ background: 'var(--red)' }} />&gt;8%</span><span><i style={{ background: 'var(--blue)' }} />negative (likely data defect)</span><span><i className="pinkey" />investigation</span></div>
        </div>
        <div className="col">
          <div className="card">
            <h3>Highest unaccounted energy</h3>
            <table className="tbl"><thead><tr><th>DT</th><th>Section</th><th className="r">7-day gap</th></tr></thead>
              <tbody>{top.map((dt: any) => <tr key={dt.id} className="click" onClick={() => openDt(dt.id)}><td>{dt.id}</td><td>{secName(dt.sec)}</td><td className="r"><b>{pct((res.get(dt.id) as any).pct)}</b></td></tr>)}</tbody></table>
          </div>
          <div className="card">
            <h3>Latest investigations</h3>
            {open.slice(-5).reverse().map((c: Case) => <button key={c.id} className="row" onClick={() => openCase(c.id)}><span className={`dot ${c.severity}`} /><span><b>{c.title}</b><small>{secName(c.sec)} · {fmtDay(c.day)} · {c.agent}</small></span></button>)}
            {!open.length && <p className="muted">None yet at this replay time.</p>}
          </div>
        </div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ ALERTS
function AlertsView({ visibleAlerts, t, openCase }: any) {
  const [sev, setSev] = useState('All');
  const list = visibleAlerts.filter((a: any) => sev === 'All' || a.sev === sev).slice().reverse();
  return (
    <>
      <Title k="Live alerts" t="Signals as they arrive" s="Press ▶ in the header to replay the stream. Data-quality noise is shown too — most alerts are not fraud." />
      <div className="chips">{['All', 'High', 'Medium', 'Low'].map(s => <button key={s} className={sev === s ? 'on' : ''} onClick={() => setSev(s)}>{s}</button>)}</div>
      <div className="card feed">
        {list.map((a: any) => <div key={a.id} className={`alert ${a.caseId ? 'click' : ''} ${a.day * H + a.hour > t - 24 ? 'fresh' : ''}`} onClick={() => a.caseId && openCase(a.caseId)}>
          <span className={`dot ${a.sev}`} /><span className="when">{fmtDayHour(a.day, a.hour)}</span>
          <span className="what"><b>{a.title}</b><small>{secName(a.sec)} · {a.source}{a.caseId ? ` · ${a.caseId}` : ' · auto-handled'}</small></span>
          {a.caseId ? <span className="go">Open case →</span> : <span className="tag grey">Data quality</span>}
        </div>)}
        {!list.length && <p className="muted">No alerts yet. Move the replay slider forward.</p>}
      </div>
    </>
  );
}

// ------------------------------------------------------------------ CASES
function CasesView({ visibleCases, sel, setSel, decisions, setDecisions, openDt }: any) {
  const [reveal, setReveal] = useState(false);
  const list: Case[] = visibleCases.slice().reverse();
  const c: Case | undefined = list.find(x => x.id === sel) || list[0];
  const [stepN, setStepN] = useState(99);
  useEffect(() => setStepN(99), [c?.id]);
  if (!c) return <><Title k="Investigations" t="No investigations yet" s="Move the replay slider forward." /></>;
  const steps = c.steps.slice(0, stepN);
  const hyp = steps.length ? steps[steps.length - 1].hyp : c.hyp0;
  const decide = (d: string) => setDecisions({ ...decisions, [c.id]: d });
  return (
    <>
      <Title k="Investigations" t="Evidence-guided cases" s="The agent keeps fraud and non-fraud explanations open, picks the next approved check, and stops at a recommendation. People decide." />
      <div className="cases">
        <div className="card caselist">
          {list.map(x => <button key={x.id} className={`row ${x.id === c.id ? 'on' : ''}`} onClick={() => setSel(x.id)}>
            <span className={`dot ${x.severity}`} /><span><b>{x.title}</b><small>{x.id} · {fmtDay(x.day)} · {decisions[x.id] || 'Awaiting review'}</small></span></button>)}
        </div>
        <div className="casedetail">
          <div className="card">
            <div className="chead">
              <div><span className="kicker">{c.id} · {c.agent} · {c.category}</span><h2>{c.title}</h2><p>{c.summary}</p>
                <div className="meta"><span className={`tag ${c.severity === 'High' ? 'red' : c.severity === 'Medium' ? 'amber' : 'grey'}`}>{c.severity} severity</span><span className="tag grey">{secName(c.sec)}</span><span className="tag grey">Opened {fmtDayHour(c.day, c.hour)}</span>
                  {c.entityType === 'DT' && <button className="linkbtn" onClick={() => openDt(c.entity)}>View energy balance →</button>}</div></div>
            </div>
          </div>
          <div className="grid2 hypgrid">
            <div className="card">
              <h3>Explanations still open <small>{steps.length ? `after step ${steps.length}` : 'at start'}</small></h3>
              <Bars items={Object.entries(hyp).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: k, value: v, tone: v > 0.6 ? 'strong' : '' }))} fmt={v => pct(v, 0)} />
              <div className="stepper"><button className="ghost" onClick={() => setStepN(0)}>Start</button><button className="ghost" disabled={stepN === 0} onClick={() => setStepN(Math.max(0, Math.min(stepN, c.steps.length) - 1))}>◀ Step</button><button className="ghost" disabled={stepN >= c.steps.length} onClick={() => setStepN(Math.min(c.steps.length, stepN + 1))}>Step ▶</button><button className="ghost" onClick={() => setStepN(99)}>All</button></div>
            </div>
            <div className="card conclusion">
              <h3>Agent recommendation</h3>
              <div className={`outcome ${OUTCOME_TONE[c.proposed]}`}>{c.proposed}</div>
              <p>{c.action}</p>
              <div className="exp"><span>Estimated exposure</span><b>{rs(c.exposure.rs)}</b><small>{c.exposure.basis}</small></div>
              <div className="decide">
                {[['Approve', 'Approved'], ['Reject', 'Rejected'], ['Need more data', 'Needs more data']].map(([l, d]) => <button key={d} className={decisions[c.id] === d ? 'on' : ''} onClick={() => decide(d)}>{l}</button>)}
              </div>
              <small className="muted">The agent cannot bill, disconnect or change records. Only an approved decision creates outputs.</small>
            </div>
          </div>
          <div className="card">
            <h3>Investigation trace</h3>
            <ol className="trace">
              {c.steps.map((s, i) => <li key={i} className={i < stepN ? '' : 'dim'}>
                <div className="tool"><code>{s.tool}</code><span>{s.ask}</span></div>
                <p>{s.result}</p>
                <div className="evs">{s.ev.map(e => <span key={e.id} className="ev" title={e.label}><b>{e.id}</b> {e.label}: {e.value}</span>)}</div>
                {s.note && <small className="muted">{s.note}</small>}
              </li>)}
            </ol>
          </div>
          <div className="card">
            <h3>Drafted outputs <small>released only after approval</small></h3>
            <ul className="outs">{c.outputs.map((o, i) => <li key={i}><span className="tag blue">{o.type}</span>{o.text}</li>)}</ul>
            <label className="reveal"><input type="checkbox" checked={reveal} onChange={e => setReveal(e.target.checked)} /> Show ground truth (evaluation view)</label>
            {reveal && <div className="truth"><b>Ground truth: {c.truth}</b> — {c.truthNote} {c.proposed === c.truth ? '✓ Agent matched.' : '✗ Agent did not commit; field verification required.'}</div>}
          </div>
        </div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ ENERGY BALANCE
function BalanceView({ D, day, dtSel, setDtSel, visibleCases, openCase }: any) {
  const dt = D.dtById.get(dtSel);
  const days = Array.from({ length: day + 1 }, (_, i) => i);
  const inp = days.map(d => dtDaily(dt, 'inp', d)), bil = days.map(d => dtDaily(dt, 'met', d) * (1 + dt.tlEst));
  const resP = days.map(d => residual(dt, d).pct * 100);
  const hd = Math.max(0, day - 44);
  const rows = Array.from({ length: day - hd + 1 }, (_, i) => hd + i);
  const vals = rows.map(d => Array.from({ length: 24 }, (_, h) => residual(dt, d, h).pct));
  const linked = visibleCases.filter((c: Case) => c.entity === dt.id || (c.key === 'I5' && (dt.id === 'NSG-DT-04' || dt.id === 'NSG-DT-05')));
  const cons = D.consumers.filter((c: any) => c.dt === dt.id);
  const r30 = residualRange(dt, Math.max(0, day - 29), day);
  return (
    <>
      <Title k="Energy balance" t={`${dt.id} · ${secName(dt.sec)}`} s={`${dt.kva} kVA on feeder ${dt.feeder} · ${cons.length} services mapped in GIS · engineering-estimated technical loss ${pct(dt.tlEst)}`} />
      <div className="chips scroll">{D.dts.filter((x: any) => x.sec === dt.sec).map((x: any) => <button key={x.id} className={x.id === dt.id ? 'on' : ''} onClick={() => setDtSel(x.id)}>{x.id}</button>)}
        <select value={dt.sec} onChange={e => setDtSel(`${e.target.value}-DT-01`)} aria-label="Section">{SECTIONS.map(s => <option key={s.code} value={s.code}>{s.name}</option>)}</select></div>
      <div className="kpis">
        <Kpi v={`${(r30.inp / 1000).toFixed(1)} MWh`} l="Energy in (30 days)" />
        <Kpi v={`${(r30.met * (1 + dt.tlEst) / 1000).toFixed(1)} MWh`} l="Billed + expected loss" />
        <Kpi v={pct(r30.pct)} l="Unaccounted (30 days)" tone={r30.pct > 0.035 ? 'red' : r30.pct < -0.04 ? 'blue' : ''} />
        <Kpi v={String(linked.length)} l="Linked investigations" />
      </div>
      {linked.map((c: Case) => <button key={c.id} className="banner" onClick={() => openCase(c.id)}><b>{c.id}</b> {c.title} → open investigation</button>)}
      <div className="card"><h3>Daily energy in vs billed + expected technical loss (kWh)</h3>
        <LineChart labels={days.map(d => fmtDay(d))} series={[{ name: 'Energy into DT', color: 'var(--teal)', values: inp }, { name: 'Billed + expected loss', color: 'var(--ink2)', values: bil, dash: true }]} /></div>
      <div className="grid2">
        <div className="card"><h3>Unaccounted energy by hour <small>last {rows.length} days</small></h3>
          <Heatmap rows={rows.map(d => fmtDay(d))} cols={Array.from({ length: 24 }, (_, h) => String(h).padStart(2, '0'))} values={vals} min={-0.3} max={0.5} title="Residual heatmap" /></div>
        <div className="card"><h3>Daily unaccounted %</h3>
          <LineChart W={480} height={300} labels={days.map(d => fmtDay(d))} series={[{ name: 'Residual %', color: 'var(--red)', values: resP }]} yfmt={v => v.toFixed(0) + '%'} />
          <p className="muted small">A theft-like gap grows at particular hours; a technical-loss change rises with load at every hour; a GIS error shows a mirror-image negative gap on a neighbour.</p></div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ GRUHA JYOTHI
function GJView({ D, day, visibleCases, openCase }: any) {
  const billedMonths = MONTHS.filter((m, i) => i < 3 && m.to + 3 <= day);
  const [m, setM] = useState(Math.max(0, billedMonths.length - 1));
  if (!billedMonths.length) return <Title k="Gruha Jyothi" t="No bill run yet" s="The July bill run happens on 3 Aug. Move the replay forward." />;
  const mm = Math.min(m, billedMonths.length - 1);
  const gjBills = D.bills.filter((b: any) => b.m === mm && D.byId.get(b.cid).cat === 'GJ');
  const bins = Array(40).fill(0); gjBills.forEach((b: any) => { const i = Math.min(39, Math.floor(b.reported / 10)); bins[i]++; });
  const readers = new Map<string, { n: number; band: number }>();
  gjBills.forEach((b: any) => { const c = D.byId.get(b.cid); if (c.meter !== 'Manual') return; const x = readers.get(c.reader) || { n: 0, band: 0 }; x.n++; if (b.reported >= 190 && b.reported < 200) x.band++; readers.set(c.reader, x); });
  const rlist = [...readers.entries()].map(([r, x]) => ({ r, ...x, share: x.band / x.n })).sort((a, b) => b.share - a.share);
  const zero = gjBills.filter((b: any) => b.zero).length, claims = D.claims.filter((c: any) => c.m === mm);
  const claimNoBill = claims.filter((c: any) => !D.billByKey.get(`${c.cid}|${mm}`)).length;
  const rcCount = new Map<string, number>(); D.consumers.forEach((c: any) => c.rc && rcCount.set(c.rc, (rcCount.get(c.rc) || 0) + 1));
  const dupRc = [...rcCount.values()].filter(v => v > 1).reduce((s, v) => s + v, 0);
  // collections: naive vs subsidy-aware (all bills of month)
  const all = D.bills.filter((b: any) => b.m === mm);
  const paid = new Set(D.payments.filter((p: any) => p.m === mm).map((p: any) => p.cid));
  const delayed = new Set(D.payments.filter((p: any) => p.m === mm && p.settledDay !== null && p.settledDay - p.day > 1).map((p: any) => p.cid));
  const naiveNonPay = all.filter((b: any) => !paid.has(b.cid)).length;
  const legitZero = all.filter((b: any) => b.zero && D.byId.get(b.cid).cat === 'GJ').length;
  const agri = all.filter((b: any) => b.zero && D.byId.get(b.cid).cat === 'AGR').length;
  const trueDefault = all.filter((b: any) => !b.zero && b.amount > 0 && !paid.has(b.cid)).length;
  const aboveCap = all.filter((b: any) => D.byId.get(b.cid).cat === 'GJ' && !b.zero && !paid.has(b.cid)).length;
  const linked = visibleCases.filter((c: Case) => ['S3', 'S4', 'S5', 'CL'].includes(c.key));
  return (
    <>
      <Title k="Gruha Jyothi" t="Subsidy-aware collections" s="Zero bills up to 200 units/month for eligible domestic households (rule configurable — verify against current GOs). Tariffs shown are illustrative." />
      <div className="chips">{billedMonths.map((x, i) => <button key={x.key} className={mm === i ? 'on' : ''} onClick={() => setM(i)}>{x.label}</button>)}</div>
      <div className="kpis">
        <Kpi v={gjBills.length.toLocaleString('en-IN')} l="Gruha Jyothi services billed" />
        <Kpi v={zero.toLocaleString('en-IN')} l="Legitimate zero bills" tone="green" />
        <Kpi v={claims.length.toLocaleString('en-IN')} l="Subsidy claims filed" />
        <Kpi v={String(claimNoBill)} l="Claims with no bill" tone={claimNoBill ? 'red' : ''} />
        <Kpi v={String(dupRc)} l="Services sharing a ration card" tone={dupRc ? 'amber' : ''} />
      </div>
      {linked.map((c: Case) => <button key={c.id} className="banner" onClick={() => openCase(c.id)}><b>{c.id}</b> {c.title} → open investigation</button>)}
      <div className="grid2">
        <div className="card"><h3>Units billed per Gruha Jyothi service · {MONTHS[mm].label}</h3>
          <Histogram W={480} bins={bins} labels={bins.map((_, i) => String(i * 10))} cap={20} highlight={i => i === 19} />
          <p className="muted small">A natural distribution falls smoothly through 200. A spike in the 190–199 bar is a pattern to test, not proof.</p></div>
        <div className="card"><h3>Share of readings in 190–199, by meter reader</h3>
          <Bars items={rlist.slice(0, 10).map(x => ({ label: `${x.r} (${x.n})`, value: x.share, tone: x.share > 0.3 ? 'hot' : '' }))} fmt={v => pct(v, 0)} /></div>
      </div>
      <div className="grid2">
        <div className="card"><h3>Who is really not paying? · {MONTHS[mm].label}</h3>
          <table className="tbl"><tbody>
            <tr><td>Naive model: no payment received</td><td className="r"><b>{naiveNonPay.toLocaleString('en-IN')}</b></td></tr>
            <tr><td className="indent">− Legitimate Gruha Jyothi zero bills</td><td className="r">{legitZero.toLocaleString('en-IN')}</td></tr>
            <tr><td className="indent">− Free agricultural supply (state-subsidised)</td><td className="r">{agri.toLocaleString('en-IN')}</td></tr>
            <tr><td className="indent">· of which above-cap GJ dues unpaid</td><td className="r">{aboveCap}</td></tr>
            <tr><td className="indent">· payments delayed in settlement (not default)</td><td className="r">{delayed.size}</td></tr>
            <tr className="total"><td>Subsidy-aware: true unpaid consumer dues</td><td className="r"><b>{trueDefault.toLocaleString('en-IN')}</b></td></tr>
          </tbody></table>
          <p className="muted small">Consumer dues and government subsidy receivables are tracked separately, so no eligible household is labelled a defaulter.</p></div>
        <div className="card"><h3>Claim reconciliation</h3>
          <table className="tbl"><thead><tr><th>Month</th><th className="r">Zero bills</th><th className="r">Claims</th><th className="r">Gap</th></tr></thead><tbody>
            {billedMonths.map((x, i) => { const z = D.bills.filter((b: any) => b.m === i && b.zero && D.byId.get(b.cid).cat === 'GJ').length, cl = D.claims.filter((c: any) => c.m === i).length; return <tr key={x.key}><td>{x.label}</td><td className="r">{z.toLocaleString('en-IN')}</td><td className="r">{cl.toLocaleString('en-IN')}</td><td className={`r ${cl - z ? 'bad' : ''}`}>{cl - z}</td></tr>; })}
          </tbody></table></div>
      </div>
    </>
  );
}

// ------------------------------------------------------------------ METER HEALTH
function HealthView({ D, day, visibleCases, openCase }: any) {
  const ev = D.events.filter((e: any) => e.day <= day);
  const ami = D.consumers.filter((c: any) => c.meter === 'AMI').length;
  const wo = new Map<string, any[]>(); D.workOrders.forEach((w: any) => { if (!wo.has(w.cid)) wo.set(w.cid, []); wo.get(w.cid)!.push(w); });
  const cls = (e: any) => {
    if (e.type.startsWith('Magnet')) return ['Tamper suspected', 'red'];
    if (e.type.startsWith('Terminal')) return (wo.get(e.cid) || []).some((w: any) => w.type === 'Meter maintenance' && Math.abs(w.day - e.day) <= 1) ? ['Authorized maintenance', 'green'] : ['Tamper suspected', 'red'];
    if (e.type.startsWith('Self')) return ['Genuine fault', 'amber'];
    if (e.type.startsWith('Load detected')) return ['Relay anomaly', 'red'];
    if (e.type.startsWith('Communication')) return ['Comms loss', 'grey'];
    return ['Info', 'grey'];
  };
  const groups: Record<string, number> = {}; ev.forEach((e: any) => { const k = cls(e)[0]; groups[k] = (groups[k] || 0) + 1; });
  const caseFor = (cid: string) => visibleCases.find((c: Case) => c.entity === cid);
  const shown = ev.filter((e: any) => !e.type.startsWith('Communication') && !e.type.startsWith('Remote')).slice().reverse();
  return (
    <>
      <Title k="Meter health" t="Fault, comms loss or tampering?" s="Events are classified using work orders and diagnostics before anyone is suspected. A confirmed fault is a maintenance finding, not an accusation." />
      <div className="kpis">
        <Kpi v={ami.toLocaleString('en-IN')} l="AMI meters" />
        <Kpi v={String(groups['Comms loss'] || 0)} l="Comms-loss events" />
        <Kpi v={String(groups['Genuine fault'] || 0)} l="Self-diagnosed faults" tone="amber" />
        <Kpi v={String(groups['Authorized maintenance'] || 0)} l="Cover opens with work order" tone="green" />
        <Kpi v={String((groups['Tamper suspected'] || 0) + (groups['Relay anomaly'] || 0))} l="Tamper / relay anomalies" tone="red" />
      </div>
      <div className="card"><h3>Meter events needing a decision</h3>
        <table className="tbl"><thead><tr><th>When</th><th>Service</th><th>Event</th><th>Classification</th><th></th></tr></thead><tbody>
          {shown.map((e: any) => { const [k, tone] = cls(e); const c = caseFor(e.cid); return <tr key={e.id}><td>{fmtDayHour(e.day, e.hour)}</td><td>{e.cid}<small className="muted"> · {secName(D.byId.get(e.cid).sec)}</small></td><td>{e.type}</td><td><span className={`tag ${tone}`}>{k}</span></td><td>{c ? <button className="linkbtn" onClick={() => openCase(c.id)}>{c.id} →</button> : k === 'Genuine fault' ? <span className="muted small">Replacement ticket drafted</span> : null}</td></tr>; })}
        </tbody></table></div>
    </>
  );
}

// ------------------------------------------------------------------ TICKETS + RAG
function TicketsView({ D, day, idx, visibleCases, openCase }: any) {
  const cur = D.tickets.filter((t: any) => !t.past && t.day <= day).slice().reverse();
  const [type, setType] = useState('All');
  const list = cur.filter((t: any) => type === 'All' || t.type === type);
  const [sel, setSel] = useState<any>(list.find((t: any) => D.P.S7.ids.includes(t.id)) || list[0]);
  const [q, setQ] = useState('');
  const active = sel && list.find((t: any) => t.id === sel.id) ? sel : list[0];
  const results = active ? idx.search(active.type + ' ' + active.text, 4).filter((r: any) => r.score > 0.12) : [];
  const qres = q.trim().length > 2 ? idx.search(q, 4) : [];
  const types = ['All', ...Array.from(new Set(cur.map((t: any) => t.type))) as string[]];
  const s7 = visibleCases.find((c: Case) => c.key === 'S7');
  const linkedCase = active && (D.P.S7.ids.includes(active.id) ? s7 : active.type === 'Illegal connection report' ? visibleCases.find((c: Case) => c.key === 'S1') : active.cid === D.P.I3.cid ? visibleCases.find((c: Case) => c.key === 'I3') : null);
  return (
    <>
      <Title k="Tickets + AI RAG" t="Have we seen this before, and what caused it?" s={`Each complaint is matched against ${D.tickets.filter((t: any) => t.past).length} closed tickets with recorded root causes and fixes (TF-IDF retrieval, in the browser).`} />
      <div className="card ask"><input value={q} onChange={e => setQ(e.target.value)} placeholder='Ask the knowledge base, e.g. "meter display blank" or "paid through SMS link"' aria-label="Search past tickets" />
        {qres.map((r: any) => <div key={r.doc.id} className="hit"><span className="score">{(r.score * 100).toFixed(0)}%</span><div><b>{r.doc.rootCause}</b><small>Fix: {r.doc.fix} · e.g. {r.doc.id}: "{r.doc.text}"</small></div></div>)}</div>
      <div className="chips scroll">{types.map(x => <button key={x} className={type === x ? 'on' : ''} onClick={() => setType(x)}>{x}</button>)}</div>
      <div className="cases">
        <div className="card caselist">{list.slice(0, 80).map((t: any) => <button key={t.id} className={`row ${active && t.id === active.id ? 'on' : ''}`} onClick={() => setSel(t)}><span className={`dot ${t.status === 'Open' ? 'Medium' : 'Low'}`} /><span><b>{t.type}</b><small>{t.id} · {fmtDay(t.day)} · {secName(t.sec)} · {t.channel}</small></span></button>)}</div>
        {active && <div className="casedetail">
          <div className="card"><span className="kicker">{active.id} · {active.channel} · {active.status}</span><h2>{active.type}</h2><p className="quote">“{active.text}”</p>
            {linkedCase && <button className="banner" onClick={() => openCase(linkedCase.id)}><b>{linkedCase.id}</b> Linked to investigation: {linkedCase.title} →</button>}</div>
          <div className="card"><h3>Similar past tickets and their root causes</h3>
            {results.map((r: any) => <div key={r.doc.id} className="hit"><span className="score">{(r.score * 100).toFixed(0)}%</span><div><b>{r.doc.rootCause}</b><small>Fix applied: {r.doc.fix}</small><small className="muted">{r.doc.id} · "{r.doc.text}"</small></div></div>)}
            {!results.length && <p className="muted">No close match in past tickets: routed to an officer as a new pattern.</p>}
            <p className="muted small">The LLM drafts a reply and a probable cause from these retrieved cases; an officer confirms before it is sent.</p></div>
        </div>}
      </div>
    </>
  );
}

// ------------------------------------------------------------------ OUTPUTS
function OutputsView({ visibleCases, decisions, openCase }: any) {
  const approved = visibleCases.filter((c: Case) => decisions[c.id] === 'Approved');
  const waiting = visibleCases.filter((c: Case) => !decisions[c.id]);
  const groups: Record<string, { c: Case; text: string }[]> = {};
  approved.forEach((c: Case) => c.outputs.forEach(o => { (groups[o.type] = groups[o.type] || []).push({ c, text: o.text }); }));
  return (
    <>
      <Title k="Outputs" t="Alerts, bills, payments and suggestions" s="Outputs are released only from approved investigations. Rejected or 'need more data' cases release nothing." />
      <div className="kpis"><Kpi v={String(approved.length)} l="Approved investigations" tone="green" /><Kpi v={String(waiting.length)} l="Awaiting officer review" tone="amber" /><Kpi v={rs(approved.reduce((s: number, c: Case) => s + c.exposure.rs, 0))} l="Exposure in approved cases (estimate)" /></div>
      {!approved.length && <div className="card"><p>No approved investigations yet. Open <b>Investigations</b> and approve a case to see its outputs here.</p></div>}
      <div className="grid2">{Object.entries(groups).map(([k, v]) => <div key={k} className="card"><h3>{k} <small>{v.length}</small></h3><ul className="outs">{v.map((x, i) => <li key={i}><button className="linkbtn" onClick={() => openCase(x.c.id)}>{x.c.id}</button> {x.text}</li>)}</ul></div>)}</div>
      {waiting.length > 0 && <div className="card"><h3>Waiting for review</h3>{waiting.map((c: Case) => <button key={c.id} className="row" onClick={() => openCase(c.id)}><span className={`dot ${c.severity}`} /><span><b>{c.title}</b><small>{c.id} · proposed: {c.proposed}</small></span></button>)}</div>}
    </>
  );
}

// ------------------------------------------------------------------ SCORECARD
function ScoreView({ D, cases, visibleCases, decisions, openCase }: any) {
  const vis = new Set(visibleCases.map((c: Case) => c.id));
  const fraud = cases.filter((c: Case) => c.truth === 'Suspected misconduct referral');
  const innocent = cases.filter((c: Case) => c.truth !== 'Suspected misconduct referral');
  const fraudFound = fraud.filter((c: Case) => vis.has(c.id) && c.proposed === c.truth).length;
  const deferred = fraud.filter((c: Case) => vis.has(c.id) && c.proposed === 'Inconclusive').length;
  const cleared = innocent.filter((c: Case) => vis.has(c.id) && c.proposed === c.truth).length;
  const wrongAcc = innocent.filter((c: Case) => c.proposed === 'Suspected misconduct referral').length;
  // naive baseline: drop >40% Sep vs Jul, or zero bill unpaid
  const naive = useMemo(() => { const paid = new Set(D.payments.filter((p: any) => p.m === 2).map((p: any) => p.cid)); const sep = D.bills.filter((b: any) => b.m === 2); return { all: sep.filter((b: any) => !paid.has(b.cid)).length, real: sep.filter((b: any) => !b.zero && b.amount > 0 && !paid.has(b.cid)).length }; }, [D]);
  return (
    <>
      <Title k="Scorecard" t="Known scenarios vs what the agents found" s="The evaluation set holds 14 known scenarios: 8 misconduct patterns and 6 innocent look-alikes. Scores update with the replay time." />
      <div className="kpis">
        <Kpi v={`${fraudFound}/${fraud.length}`} l="Misconduct patterns correctly referred" tone="green" />
        <Kpi v={String(deferred)} l="Deferred to field check (inconclusive)" tone="amber" />
        <Kpi v={`${cleared}/${innocent.length}`} l="Innocent look-alikes correctly cleared" tone="green" />
        <Kpi v={String(wrongAcc)} l="Honest cases referred as misconduct" />
        <Kpi v={`${naive.all.toLocaleString('en-IN')} → ${naive.real}`} l="Sep 'non-payers': naive rule → subsidy-aware" tone="red" />
      </div>
      <div className="card"><table className="tbl"><thead><tr><th>Case</th><th>Scenario</th><th>Detected</th><th>Agent proposed</th><th>Ground truth</th><th>Officer</th></tr></thead><tbody>
        {cases.map((c: Case) => <tr key={c.id} className={vis.has(c.id) ? 'click' : 'dimrow'} onClick={() => vis.has(c.id) && openCase(c.id)}><td>{c.id}</td><td>{c.title}</td><td>{vis.has(c.id) ? fmtDay(c.day) : '—'}</td><td><span className={`tag ${OUTCOME_TONE[c.proposed]}`}>{c.proposed}</span></td><td>{c.truth} {c.proposed === c.truth ? '✓' : '·'}</td><td>{decisions[c.id] || '—'}</td></tr>)}
      </tbody></table>
        <p className="muted small">This scorecard measures the pipeline against the known scenarios in the evaluation set. Field performance is measured separately in a pilot.</p></div>
    </>
  );
}

// ------------------------------------------------------------------ DATA
function DataView({ D }: any) {
  const rows = [
    ['consumers.csv', `${D.consumers.length} services`, 'Service id, section, DT (GIS), category, meter type, reader, location'],
    ['bills.csv', `${D.bills.length} bills`, 'Jul–Sep bills: units consumed (truth), units reported, amount, zero-bill flag'],
    ['payments.csv', `${D.payments.length} payments`, 'Channel, counter, payment day and bank settlement day'],
    ['dt_hourly.csv', `${D.dts.length * DAYS * 24} rows`, 'Hourly energy into each DT and billed/estimated energy downstream'],
    ['meter_events.csv', `${D.events.length} events`, 'AMI tamper, fault, comms and relay events'],
    ['work_orders.csv', `${D.workOrders.length} orders`, 'Disconnections, maintenance, net-metering'],
    ['tickets.csv', `${D.tickets.length} tickets`, 'Past (with root cause) and current complaints'],
    ['gj_claims.csv', `${D.claims.length} claims`, 'Gruha Jyothi subsidy claims by month'],
    ['ground_truth.csv', '14 scenarios', 'Planted scenarios and their true outcome (for evaluation only)'],
  ];
  return (
    <>
      <Title k="Data + downloads" t="The dataset" s="Evaluation dataset for one Telangana-style circle (seed 20261016): every run produces identical records, so results can be reproduced." />
      <div className="card"><table className="tbl"><thead><tr><th>File</th><th>Size</th><th>Contents</th></tr></thead><tbody>{rows.map(r => <tr key={r[0]}><td><code>{r[0]}</code></td><td>{r[1]}</td><td>{r[2]}</td></tr>)}</tbody></table>
        {process.env.NEXT_PUBLIC_PREVIEW === '1'
          ? <p className="muted">CSV downloads are available in the deployed application.</p>
          : <button className="primary" onClick={() => downloadAll(D)}>Download all CSV files</button>}</div>
      <div className="card"><h3>Assumptions</h3><ul className="plain">
        <li>Window: 1 Jul – 15 Oct 2026. July–September are billed; October is in progress (manual meters use provisional estimates).</li>
        <li>Six sections around Hyderabad's south-west, 60 DTs, ~4,500 services; hourly DT energy; daily consumer energy.</li>
        <li>Gruha Jyothi: zero bill when units ≤ 200 for enrolled domestic services; above the limit the full bill applies. Rule is configurable — verify against current GOs.</li>
        <li>Tariffs and ₹/kWh values are illustrative, not TGERC-approved figures.</li>
        <li>Agent reasoning runs over computed evidence; an LLM can be connected to phrase explanations.</li>
      </ul></div>
    </>
  );
}
