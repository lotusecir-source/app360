'use client';
import React, { useState } from 'react';

export function LineChart({ series, labels, height = 220, yfmt = (v: number) => v.toFixed(0), marks = [] as { i: number; label: string }[], W = 760 }:
  { series: { name: string; color: string; values: number[]; dash?: boolean }[]; labels: string[]; height?: number; W?: number; yfmt?: (v: number) => string; marks?: { i: number; label: string }[] }) {
  const [hov, setHov] = useState<number | null>(null);
  const Hh = height, L = 52, Rr = 12, T = 12, B = 26;
  const all = series.flatMap(s => s.values).filter(v => isFinite(v));
  let min = Math.min(...all), max = Math.max(...all); if (min > 0) min = 0; if (max === min) max = min + 1;
  const pad = (max - min) * 0.08; max += pad; if (min < 0) min -= pad;
  const n = labels.length; const x = (i: number) => L + (i / Math.max(1, n - 1)) * (W - L - Rr); const y = (v: number) => T + (1 - (v - min) / (max - min)) * (Hh - T - B);
  const ticks = 4; const tv = Array.from({ length: ticks + 1 }, (_, i) => min + (i / ticks) * (max - min));
  const step = Math.ceil(n / (W < 600 ? 5 : 8));
  return (
    <div className="chart">
      <svg viewBox={`0 0 ${W} ${Hh}`} role="img" onMouseLeave={() => setHov(null)}
        onMouseMove={e => { const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect(); const px = ((e.clientX - r.left) / r.width) * W; const i = Math.round(((px - L) / (W - L - Rr)) * (n - 1)); setHov(i >= 0 && i < n ? i : null); }}>
        {tv.map((v, i) => <g key={i}><line x1={L} x2={W - Rr} y1={y(v)} y2={y(v)} className="grid" /><text x={L - 6} y={y(v) + 4} className="axis" textAnchor="end">{yfmt(v)}</text></g>)}
        {min < 0 && <line x1={L} x2={W - Rr} y1={y(0)} y2={y(0)} className="zero" />}
        {labels.map((l, i) => i % step === 0 && <text key={i} x={x(i)} y={Hh - 8} className="axis" textAnchor="middle">{l}</text>)}
        {marks.map((m, k) => <g key={k}><line x1={x(m.i)} x2={x(m.i)} y1={T} y2={Hh - B} className="mark" /><text x={x(m.i) + 4} y={T + 10} className="marktext">{m.label}</text></g>)}
        {series.map(s => <polyline key={s.name} fill="none" stroke={s.color} strokeWidth={2} strokeDasharray={s.dash ? '5 4' : undefined} points={s.values.map((v, i) => `${x(i)},${y(v)}`).join(' ')} />)}
        {hov !== null && <g><line x1={x(hov)} x2={x(hov)} y1={T} y2={Hh - B} className="hover" />{series.map(s => <circle key={s.name} cx={x(hov)} cy={y(s.values[hov])} r={3.5} fill={s.color} />)}</g>}
      </svg>
      <div className="legend">
        {series.map(s => <span key={s.name}><i style={{ background: s.color }} />{s.name}{hov !== null && <b> {yfmt(s.values[hov])}</b>}</span>)}
        {hov !== null && <span className="muted">· {labels[hov]}</span>}
      </div>
    </div>
  );
}

export function Heatmap({ rows, cols, values, min, max, rowLabel, title }: { rows: string[]; cols: string[]; values: number[][]; min: number; max: number; rowLabel?: string; title?: string }) {
  const [hov, setHov] = useState<{ r: number; c: number } | null>(null);
  const cw = 22, ch = 11, L = 54, T = 18;
  const W = L + cols.length * cw + 6, Hh = T + rows.length * ch + 4;
  const col = (v: number) => {
    const t = Math.max(-1, Math.min(1, v >= 0 ? v / max : -v / min));
    if (v >= 0) return `color-mix(in srgb, var(--hot) ${Math.round(t * 100)}%, var(--cell))`;
    return `color-mix(in srgb, var(--cold) ${Math.round(Math.abs(t) * 100)}%, var(--cell))`;
  };
  return (
    <div className="chart">
      <svg viewBox={`0 0 ${W} ${Hh}`} role="img" aria-label={title} onMouseLeave={() => setHov(null)} style={{ maxWidth: W * 1.2 }}>
        {cols.map((c, i) => i % 3 === 0 && <text key={i} x={L + i * cw + cw / 2} y={12} className="axis" textAnchor="middle">{c}</text>)}
        {rows.map((r, j) => <g key={j}>
          {j % 4 === 0 && <text x={L - 6} y={T + j * ch + 9} className="axis" textAnchor="end">{r}</text>}
          {values[j].map((v, i) => <rect key={i} x={L + i * cw} y={T + j * ch} width={cw - 1} height={ch - 1} fill={col(v)} onMouseEnter={() => setHov({ r: j, c: i })} />)}
        </g>)}
      </svg>
      <div className="legend">
        <span><i style={{ background: 'var(--cold)' }} />more billed than supplied</span>
        <span><i style={{ background: 'var(--hot)' }} />unaccounted energy</span>
        {hov && <span className="muted">· {rows[hov.r]} {cols[hov.c]}:00 → <b>{(values[hov.r][hov.c] * 100).toFixed(1)}%</b></span>}
      </div>
    </div>
  );
}

export function Histogram({ bins, labels, cap, highlight, W = 760 }: { bins: number[]; labels: string[]; cap?: number; highlight?: (i: number) => boolean; W?: number }) {
  const [hov, setHov] = useState<number | null>(null);
  const Hh = W < 600 ? 260 : 220, L = 44, T = 10, B = 26; const max = Math.max(...bins, 1);
  const bw = (W - L - 8) / bins.length;
  return (
    <div className="chart">
      <svg viewBox={`0 0 ${W} ${Hh}`} role="img" onMouseLeave={() => setHov(null)}>
        {[0, 0.5, 1].map(t => <g key={t}><line x1={L} x2={W - 8} y1={T + (1 - t) * (Hh - T - B)} y2={T + (1 - t) * (Hh - T - B)} className="grid" /><text x={L - 6} y={T + (1 - t) * (Hh - T - B) + 4} textAnchor="end" className="axis">{Math.round(max * t)}</text></g>)}
        {bins.map((v, i) => { const h = (v / max) * (Hh - T - B); return <rect key={i} x={L + i * bw + 1} y={Hh - B - h} width={bw - 2} height={h} rx={2} className={highlight && highlight(i) ? 'bar hl' : 'bar'} onMouseEnter={() => setHov(i)} />; })}
        {labels.map((l, i) => i % 4 === 0 && <text key={i} x={L + i * bw} y={Hh - 8} className="axis">{l}</text>)}
        {cap !== undefined && <g><line x1={L + cap * bw} x2={L + cap * bw} y1={T} y2={Hh - B} className="cap" /><text x={L + cap * bw + 4} y={T + 12} className="captext">200-unit limit</text></g>}
      </svg>
      <div className="legend">{hov !== null ? <span><b>{bins[hov]}</b> bills at {labels[hov]}–{+labels[hov] + 9} units</span> : <span className="muted">Hover a bar for counts</span>}</div>
    </div>
  );
}

export function Bars({ items, fmt = (v: number) => String(v) }: { items: { label: string; value: number; tone?: string }[]; fmt?: (v: number) => string }) {
  const max = Math.max(...items.map(i => Math.abs(i.value)), 1e-9);
  return <div className="hbars">{items.map(i => <div key={i.label} className="hbar"><span className="lbl">{i.label}</span><span className="track"><span className={`fill ${i.tone || ''}`} style={{ width: `${(Math.abs(i.value) / max) * 100}%` }} /></span><span className="val">{fmt(i.value)}</span></div>)}</div>;
}
