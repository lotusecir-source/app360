'use client';
import React, { useMemo, useState } from 'react';
import { DAYS, H, SECTIONS, fmtDay, residualRange, dayDate } from '@/lib/data';
import { Case, rs } from '@/lib/cases';
import { LOGO_LIGHT, LOGO_DARK, LOGO_MARK } from '@/lib/logos';

const hash = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return h >>> 0; };
const jit = (k: number) => { const x = Math.sin(k * 12.9898) * 43758.5453; return x - Math.floor(x) - 0.5; };
const lerp = (a: ArrayLike<number>, x: number) => { const i = Math.max(0, Math.min(a.length - 1, Math.floor(x))); const j = Math.min(a.length - 1, i + 1); const f = x - i; return a[i] * (1 - f) + a[j] * f; };
const fmtNum = (v: number, d = 0) => v.toLocaleString('en-IN', { maximumFractionDigits: d, minimumFractionDigits: d });
const hhmm = (t: number) => `${String(Math.floor(t % H)).padStart(2, '0')}:${String(Math.floor((t * 60) % 60)).padStart(2, '0')}`;
const clockLabel = (tf: number) => `${fmtDay(Math.floor(tf / H))} 2026 · ${hhmm(tf)} IST`;
const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const longDay = (d: number) => { const x = dayDate(d); return `${WD[x.getUTCDay()].slice(0, 3)}, ${fmtDay(d)}`; };
const kfmt = (v: number) => v >= 1e5 ? `₹${(v / 1e5).toFixed(1)}L` : `₹${Math.round(v / 1000)}K`;

export function usePrecomputed(D: any) {
  return useMemo(() => {
    const N = DAYS * H;
    const inp = new Float64Array(N), bil = new Float64Array(N);
    const secInp: Record<string, Float64Array> = {}, secBil: Record<string, Float64Array> = {};
    SECTIONS.forEach(s => { secInp[s.code] = new Float64Array(N); secBil[s.code] = new Float64Array(N); });
    for (const dt of D.dts) for (let i = 0; i < N; i++) { const a = dt.inp[i], b = dt.met[i] * (1 + dt.tlEst); inp[i] += a; bil[i] += b; secInp[dt.sec][i] += a; secBil[dt.sec][i] += b; }
    const payAmt = new Float64Array(N), payN = new Float64Array(N);
    const payHour = (p: any) => { const r = hash(p.id) % 100; return p.channel.startsWith('Counter') ? 9 + (r % 9) : (r < 8 ? r % 7 : 7 + (r % 17)); };
    const pays = D.payments.map((p: any) => { const hour = payHour(p); return { ...p, hour, t: p.day * H + hour + (hash(p.id + 'm') % 60) / 60, sec: D.byId.get(p.cid).sec }; }).sort((a: any, b: any) => a.t - b.t);
    for (const p of pays) { const i = p.day * H + p.hour; if (i < N) { payAmt[i] += p.amt; payN[i]++; } }
    const billedTotal = D.bills.filter((b: any) => b.m === 2).reduce((s: number, b: any) => s + b.amount, 0);
    const ami = D.consumers.filter((c: any) => c.meter === 'AMI').length;
    return { inp, bil, secInp, secBil, payAmt, payN, pays, billedTotal, ami };
  }, [D]);
}

// settlement status of a payment as seen at time `now` (hours)
const status = (p: any, now: number) => {
  if (p.settledDay !== null && p.settledDay * H + 10 <= now) return 'Settled';
  if (now - p.t <= 34) return 'Awaiting';
  return 'Unsettled';
};

function LiveLoad({ P, tf, series }: any) {
  const [hov, setHov] = useState<number | null>(null);
  const SA = series ? series.a : P.inp, SB = series ? series.b : P.bil;
  const span = 48; const end = tf; const start = Math.max(0, end - span);
  const n = 97; const xs = Array.from({ length: n }, (_, k) => start + (k / (n - 1)) * (end - start));
  const a = xs.map(x => lerp(SA, x)), b = xs.map(x => lerp(SB, x));
  const W = 780, Hh = 260, L = 46, R = 14, T = 14, B = 28;
  const max = Math.max(...a, ...b) * 1.1;
  const X = (i: number) => L + (i / (n - 1)) * (W - L - R), Y = (v: number) => T + (1 - v / max) * (Hh - T - B);
  const path = (arr: number[]) => arr.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join('');
  const gap = path(a) + b.slice().reverse().map((v, i) => `L${X(n - 1 - i).toFixed(1)},${Y(v).toFixed(1)}`).join('') + 'Z';
  const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => f * max);
  const hourTicks: number[] = []; for (let hh = Math.ceil(start / 6) * 6; hh <= end; hh += 6) hourTicks.push(hh);
  return <div className="chart">
    <svg viewBox={`0 0 ${W} ${Hh}`} role="img" aria-label="Energy in vs billed, last 48 hours"
      onMouseMove={e => { const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect(); const px = ((e.clientX - r.left) / r.width) * W; const i = Math.round(((px - L) / (W - L - R)) * (n - 1)); setHov(i >= 0 && i < n ? i : null); }} onMouseLeave={() => setHov(null)}>
      {ticks.map((v, i) => <g key={i}><line x1={L} x2={W - R} y1={Y(v)} y2={Y(v)} className="dgridl" /><text x={L - 6} y={Y(v) + 4} className="daxis" textAnchor="end">{series ? v.toFixed(0) : (v / 1000).toFixed(1)}</text></g>)}
      {hourTicks.map(hh => { const i = ((hh - start) / (end - start)) * (n - 1); return <text key={hh} x={X(i)} y={Hh - 9} className="daxis" textAnchor="middle">{hh % 24 === 0 ? fmtDay(hh / 24) : `${String(hh % 24).padStart(2, '0')}:00`}</text>; })}
      <path d={gap} fill="var(--d-open)" fillOpacity={0.35} />
      <path d={path(b)} fill="none" stroke="var(--d-ink2)" strokeWidth={1.6} strokeDasharray="5 4" />
      <path d={path(a)} fill="none" stroke="var(--d-paid)" strokeWidth={2.4} />
      <circle cx={X(n - 1)} cy={Y(a[n - 1])} r={9} className="dpulse" />
      <circle cx={X(n - 1)} cy={Y(a[n - 1])} r={4} fill="var(--d-paid)" stroke="var(--d-card)" strokeWidth={2} />
      {hov !== null && <g><line x1={X(hov)} x2={X(hov)} y1={T} y2={Hh - B} className="dhover" /><circle cx={X(hov)} cy={Y(a[hov])} r={3.5} fill="var(--d-paid)" /><circle cx={X(hov)} cy={Y(b[hov])} r={3.5} fill="var(--d-ink2)" /></g>}
    </svg>
    <div className="dlegend">
      <span><i style={{ background: 'var(--d-paid)' }} />{series ? `Energy into ${series.id} (kW)` : 'Energy into all DTs (MW)'}</span>
      <span><i style={{ background: 'var(--d-ink2)' }} />Billed + expected loss</span>
      <span><i style={{ background: 'var(--d-open)' }} />Unaccounted gap</span>
      {hov !== null && <span className="dmuted">· {clockLabel(xs[hov])}: <b>{series ? `${a[hov].toFixed(0)} kW` : `${(a[hov] / 1000).toFixed(2)} MW`}</b>, gap <b>{(((a[hov] - b[hov]) / a[hov]) * 100).toFixed(1)}%</b></span>}
    </div>
  </div>;
}

function Stacked({ days }: { days: { label: string; settled: number; awaiting: number; unsettled: number; today: boolean }[] }) {
  const [hov, setHov] = useState<number | null>(null);
  const W = 640, Hh = 300, L = 44, R = 8, T = 16, B = 30;
  const max = Math.max(...days.map(d => d.settled + d.awaiting + d.unsettled), 1) * 1.08;
  const step = (W - L - R) / days.length, bw = step * 0.72;
  const Y = (v: number) => T + (1 - v / max) * (Hh - T - B);
  const ticks = [0, 0.5, 1].map(f => f * max);
  const seg = (x: number, v0: number, v1: number, cls: string, label: boolean, key: string) => {
    if (v1 - v0 <= 0) return null; const y0 = Y(v0), y1 = Y(v1); const h = y0 - y1;
    return <g key={key}><rect x={x} y={y1} width={bw} height={Math.max(0, h - 1)} className={cls} />{label && h > 22 && bw >= 28 && <text x={x + bw / 2} y={y1 + h / 2 + 4} textAnchor="middle" className="dbarlabel">{kfmt(v1 - v0).replace('₹', '')}</text>}</g>;
  };
  return <div className="chart">
    <div className="dlegend dlegtop"><span><i style={{ background: 'var(--d-open)' }} />Awaiting settlement</span><span><i style={{ background: 'var(--d-overdue)' }} />Unsettled after T+1</span><span><i style={{ background: 'var(--d-paid)' }} />Settled</span></div>
    <svg viewBox={`0 0 ${W} ${Hh}`} role="img" aria-label="Daily collections by settlement status" onMouseLeave={() => setHov(null)}>
      {ticks.map((v, i) => <g key={i}><line x1={L} x2={W - R} y1={Y(v)} y2={Y(v)} className="dgridl dotted" /><text x={L - 6} y={Y(v) + 4} className="daxis" textAnchor="end">{kfmt(v)}</text></g>)}
      {days.map((d, i) => { const x = L + i * step + (step - bw) / 2; return <g key={i} onMouseEnter={() => setHov(i)}>
        <rect x={L + i * step} y={T} width={step} height={Hh - T - B} fill="transparent" />
        {seg(x, 0, d.unsettled, 'b-overdue', true, 'u')}
        {seg(x, d.unsettled, d.unsettled + d.awaiting, 'b-open', false, 'a')}
        {seg(x, d.unsettled + d.awaiting, d.unsettled + d.awaiting + d.settled, 'b-paid', true, 's')}
        {d.today && <text x={x + bw / 2} y={Y(d.settled + d.awaiting + d.unsettled) - 6} textAnchor="middle" className="dlive">LIVE</text>}
        {i % 2 === (days.length - 1) % 2 && <text x={x + bw / 2} y={Hh - 10} textAnchor="middle" className="daxis">{d.label}</text>}
      </g>; })}
    </svg>
    <div className="dlegend">{hov !== null ? <span><b>{days[hov].label}</b> · settled {rs(days[hov].settled)} · awaiting {rs(days[hov].awaiting)} · unsettled <b>{rs(days[hov].unsettled)}</b></span> : <span className="dmuted">Hover a column for the breakdown</span>}</div>
  </div>;
}

export default function Dashboard({ D, tf, live, setLive, speed, setSpeed, visibleCases, decisions, openCase, openDt, setView, P }: any) {
  const N = DAYS * H; const now = Math.min(tf, N - 1.001); const hi = Math.floor(now);
  const day = Math.floor(now / H); const k = Math.floor(now * 60);
  const dayStart = day * H;

  // KPI 1: collections today
  let collToday = 0, collN = 0; for (const p of P.pays) { if (p.t >= dayStart && p.t <= now) { collToday += p.amt; collN++; } }
  // KPI 2: revenue at risk
  const open = visibleCases.filter((c: Case) => !decisions[c.id]);
  const atRisk = open.reduce((s: number, c: Case) => s + c.exposure.rs, 0);
  const high = open.filter((c: Case) => c.severity === 'High').length;
  // KPI 3: unaccounted energy now
  const loadNow = lerp(P.inp, now) * (1 + jit(k) * 0.008);
  let g24a = 0, g24b = 0; for (let i = Math.max(0, hi - 23); i <= hi; i++) { g24a += P.inp[i]; g24b += P.bil[i]; }
  const gapNow = Math.max(0, (g24a - g24b) / g24a);
  const dtRisk = useMemo(() => D.dts.map((dt: any) => ({ dt, r: residualRange(dt, Math.max(0, day - 1), day).pct })), [D, day]);
  const hotCount = dtRisk.filter((x: any) => x.r > 0.08).length;

  // live transactions table
  const recent = useMemo(() => { const out: any[] = []; for (let i = P.pays.length - 1; i >= 0 && out.length < 8; i--) if (P.pays[i].t <= now) out.push(P.pays[i]); return out; }, [P, Math.floor(now * 60)]);
  const maxAmt = Math.max(...recent.map((p: any) => p.amt), 1);
  let todayPending = 0; for (const p of P.pays) if (p.t >= dayStart && p.t <= now && status(p, now) !== 'Settled') todayPending += p.amt;

  // section table
  const monthStart = day >= 92 ? 92 : day >= 62 ? 62 : day >= 31 ? 31 : 0;
  const secRows = SECTIONS.map(s => {
    let a = 0, b = 0; for (let i = Math.max(0, hi - 23); i <= hi; i++) { a += P.secInp[s.code][i]; b += P.secBil[s.code][i]; }
    let mtd = 0; for (const p of P.pays) if (p.sec === s.code && p.t >= monthStart * H && p.t <= now) mtd += p.amt;
    return { s, e24: a / 1000, gap: (a - b) / a, mtd, cases: open.filter((c: Case) => c.sec === s.code).length };
  });
  const maxE = Math.max(...secRows.map(r => r.e24)), maxM = Math.max(...secRows.map(r => r.mtd), 1);
  const totE = secRows.reduce((x, r) => x + r.e24, 0), totM = secRows.reduce((x, r) => x + r.mtd, 0);

  // stacked daily collections (last 14 days)
  const cols = useMemo(() => {
    const out = []; for (let d = Math.max(0, day - 13); d <= day; d++) {
      let settled = 0, awaiting = 0, unsettled = 0;
      for (const p of P.pays) { if (p.day !== d || p.t > now) continue; const st = status(p, now); if (st === 'Settled') settled += p.amt; else if (st === 'Awaiting') awaiting += p.amt; else unsettled += p.amt; }
      out.push({ label: fmtDay(d), settled, awaiting, unsettled, today: d === day });
    } return out;
  }, [P, day, Math.floor(now * 12)]);

  // hotspot chart focus
  const hot = [...dtRisk].sort((x: any, y: any) => Math.abs(y.r) - Math.abs(x.r)).slice(0, 3);
  const [focus, setFocus] = useState<string>('circle');
  const series = useMemo(() => { if (focus === 'circle') return null; const dt = D.dtById.get(focus); const b = new Float64Array(dt.met.length); for (let i = 0; i < b.length; i++) b[i] = dt.met[i] * (1 + dt.tlEst); return { id: dt.id, a: dt.inp, b }; }, [D, focus]);
  const working = open.slice(-3).reverse().map((c: Case, i: number) => ({ c, s: c.steps[(Math.floor(now * 6) + i) % c.steps.length] }));

  return (
    <>
      <div className="dtop">
        <div className="dkpis">
          <div className="dkpi k1"><span>Collected today</span><b>{rs(collToday)}</b><small>{fmtNum(collN)} payments so far</small></div>
          <div className="dkpi k2" role="button" tabIndex={0} onClick={() => setView('cases')}><span>Revenue at risk (open cases)</span><b>{rs(atRisk)}</b><small>{high} high severity · {open.length} awaiting review</small></div>
          <div className="dkpi k3"><span>Unaccounted energy (last 24 h)</span><b>{(gapNow * 100).toFixed(2)}%</b><small>{(loadNow / 1000).toFixed(2)} MW load · {hotCount} DT hotspot{hotCount === 1 ? '' : 's'} &gt; 8%</small></div>
        </div>
        <div className="dcard dtable-wrap">
          <table className="dtable">
            <thead><tr><th>Receipt</th><th>Service</th><th>Paid at</th><th>Section</th><th>Channel</th><th className="r">Amount (₹)</th><th>Bank status</th></tr></thead>
            <tbody>
              {recent.map((p: any, i: number) => { const st = status(p, now); return <tr key={p.id} className={i === 0 ? 'fresh' : ''}>
                <td>{p.id.replace('PAY-', '')}</td><td>{p.cid}</td><td>{longDay(p.day)} {hhmm(p.t)}</td><td>{SECTIONS.find(s => s.code === p.sec)!.name.replace(' (rural)', '')}</td><td>{p.counter || p.channel}</td>
                <td className="r bar"><span style={{ width: `${(p.amt / maxAmt) * 100}%` }} /><em>{fmtNum(p.amt)}</em></td>
                <td><span className={`dpill ${st === 'Unsettled' ? 'bad' : st === 'Awaiting' ? 'wait' : 'ok'}`}>{st === 'Awaiting' ? 'Settles T+1' : st}</span></td></tr>; })}
            </tbody>
            <tfoot><tr><td colSpan={5}>Total today</td><td className="r">{fmtNum(collToday)}</td><td className="dmutedcell">{rs(todayPending)} awaiting bank</td></tr></tfoot>
          </table>
        </div>
      </div>

      <div className="dbottom">
        <div className="dcard">
          <table className="dtable sect">
            <thead><tr><th>Section</th><th className="r">Energy in, last 24 h (MWh)</th><th className="r">Collected, month to date (₹)</th><th className="r nw">24 h gap</th></tr></thead>
            <tbody>{secRows.map(r => <tr key={r.s.code}>
              <td>{r.s.name}{r.cases > 0 && <span className="dcase">{r.cases}</span>}</td>
              <td className="r cellbar"><span style={{ width: `${(r.e24 / maxE) * 100}%` }} /><em>{r.e24.toFixed(2)}</em></td>
              <td className="r cellbar strong"><span style={{ width: `${(r.mtd / maxM) * 100}%` }} /><em>{fmtNum(r.mtd)}</em></td>
              <td className={`r ${r.gap > 0.03 ? 'warn' : ''}`}>{(r.gap * 100).toFixed(1)}%</td></tr>)}</tbody>
            <tfoot><tr><td>Circle</td><td className="r">{totE.toFixed(2)}</td><td className="r">{fmtNum(totM)}</td><td></td></tr></tfoot>
          </table>
          <p className="dnote">Red numbers next to a section are open investigations. Gap is energy not matched by billing after expected technical loss.</p>
        </div>
        <div className="dcard"><Stacked days={cols} /></div>
      </div>

      <div className="dbottom wide">
        <div className="dcard">
          <h2 className="dh">{series ? `${series.id}: energy in vs billed` : 'Circle load vs billed'}, last 48 hours</h2>
          <div className="dchips">
            <button className={focus === 'circle' ? 'on' : ''} onClick={() => setFocus('circle')}>Whole circle</button>
            {hot.map((h: any) => <button key={h.dt.id} className={focus === h.dt.id ? 'on' : ''} onClick={() => setFocus(h.dt.id)}>Hotspot {h.dt.id} · {(h.r * 100).toFixed(1)}%</button>)}
          </div>
          <LiveLoad P={P} tf={now} series={series} />
        </div>
        <div className="dcard">
          <h2 className="dh">Agents at work</h2>
          {working.map(({ c, s }: any) => <button key={c.id} className="dagent" onClick={() => openCase(c.id)}><span className="dspin" /><span><b>{c.agent}</b><small>{c.id} · {c.title}</small><code>{s.tool}</code></span></button>)}
          {!working.length && <p className="dmuted">No open investigations.</p>}
          <h2 className="dh" style={{ marginTop: 14 }}>Transformer health</h2>
          <div className="ddt">{dtRisk.map(({ dt, r }: any) => <button key={dt.id} title={`${dt.id}: ${(r * 100).toFixed(1)}%`} onClick={() => openDt(dt.id)} className={r > 0.08 ? 'c4' : r > 0.035 ? 'c3' : r < -0.04 ? 'c0' : 'c2'} aria-label={`${dt.id} ${(r * 100).toFixed(1)} percent`} />)}</div>
          <div className="dlegend"><span><i className="c2" />normal</span><span><i className="c3" />3.5–8%</span><span><i className="c4" />&gt; 8%</span><span><i className="c0" />negative</span></div>
        </div>
      </div>

    </>
  );
}


export const TABS: { id: string; label: string }[] = [
  { id: 'live', label: 'Overview' }, { id: 'map', label: 'Map' }, { id: 'cases', label: 'Investigations' },
  { id: 'balance', label: 'Energy balance' }, { id: 'gj', label: 'Gruha Jyothi' },
];
export const MORE: { id: string; label: string }[] = [
  { id: 'alerts', label: 'Live alerts' }, { id: 'health', label: 'Meter health' }, { id: 'tickets', label: 'Tickets + AI RAG' },
  { id: 'outputs', label: 'Outputs' }, { id: 'score', label: 'Scorecard' }, { id: 'data', label: 'Data + downloads' },
];

export function DashHeader({ view, setView, live, setLive, pending, title }: any) {
  const [more, setMore] = useState(false);
  const inMore = MORE.find(m => m.id === view);
  const ref = React.useRef<HTMLDivElement>(null);
  const navRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => { try { const on = navRef.current?.querySelector('button.on:not(.dlivebtn)') as HTMLElement | null; if (on && getComputedStyle(on).display !== 'none') on.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch { } }, [view]);
  React.useEffect(() => {
    if (!more) return;
    const close = (e: any) => { if (e.type === 'keydown' ? e.key === 'Escape' : !ref.current?.contains(e.target)) setMore(false); };
    document.addEventListener('mousedown', close); document.addEventListener('keydown', close);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', close); };
  }, [more]);
  return (
    <header className="dbar">
      <div className="dbrand">
        <span className="dlogos"><img className="lg-light" src={LOGO_LIGHT} alt="Lotus Cyber Security" /><img className="lg-dark" src={LOGO_DARK} alt="Lotus Cyber Security" /></span>
        <span className="dsep" aria-hidden="true" />
        <div><h1>{title}</h1><span className="dsub">UNVEIL SHADOWS · TELANGANA CIRCLE</span></div>
      </div>
      <div className="dtabs">
      <nav className="dtabs-scroll" aria-label="Screens" ref={navRef}>
        {TABS.map(t => <button key={t.id} className={view === t.id ? 'on' : ''} onClick={() => { setMore(false); setView(t.id); }}>{t.label}{t.id === 'cases' && pending > 0 && <em className="dbadge">{pending}</em>}</button>)}
        {MORE.map(m => <button key={'x' + m.id} className={`tab-extra ${view === m.id ? 'on' : ''}`} onClick={() => setView(m.id)}>{m.label}</button>)}
        <div className="dmore" ref={ref}>
          <button className={inMore ? 'on' : ''} aria-expanded={more} onClick={() => setMore(!more)}>{inMore ? inMore.label : 'More'} ▾</button>
          {more && <div className="dmenu" role="menu">{MORE.map(m => <button key={m.id} role="menuitem" className={view === m.id ? 'on' : ''} onClick={() => { setMore(false); setView(m.id); }}>{m.label}</button>)}</div>}
        </div>
      </nav>
        <button className={`dlivebtn ${live ? 'on' : ''}`} onClick={() => setLive(!live)}><span className="livedot" />{live ? 'Live' : 'Go live'}</button>
      </div>
    </header>
  );
}

export function ClockBar({ tf, live, speed, setSpeed, children }: any) {
  return (
    <div className="dclock">
      <span className={`dstate ${live ? 'on' : ''}`}><span className="livedot" />{live ? 'Streaming' : 'Paused'} · {clockLabel(Math.min(tf, DAYS * H - 1))}</span>
      {live && <button className="dspeed" onClick={() => setSpeed(speed === 1 ? 12 : 1)}>{speed === 1 ? 'Speed 1× (5 min/s)' : 'Speed 12× (1 h/s)'}</button>}
      {children}
    </div>
  );
}

export function DashFooter({ setView }: any) {
  return (
    <footer className="dfoot">
      <span className="dfbrand"><img src={LOGO_MARK} alt="" />© 2026 Lotus Cyber Security · Unveil Shadows<small>Figures shown are sample data</small></span>
      <nav><button onClick={() => setView('balance')}>Energy balance</button><button onClick={() => setView('health')}>Meter health</button><button onClick={() => setView('tickets')}>Tickets + AI RAG</button><button onClick={() => setView('score')}>Scorecard</button><button onClick={() => setView('data')}>Data</button></nav>
    </footer>
  );
}
